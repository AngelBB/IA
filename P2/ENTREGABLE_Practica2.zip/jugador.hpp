/*
 * Alunmo: Angel Barrilao Bensrhir
 * DNI:75170767M
 * Grupo: A3
 * */
 
#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"
#include <list>
#include <vector>
#include <stdlib.h>
#include <iostream>


struct estado{ 
		int fila;
		int columna;
		int orientacion;
		estado(int fil, int col,int o):fila(fil), columna(col), orientacion(o){}
		estado(int fil, int col):fila(fil), columna(col){}
		estado(){} 
		void operator=(const estado &otro){
			fila=otro.fila;
			columna=otro.columna;
		}
		bool operator!=(const estado &otro){
			//Usamos el OR por que se puede dar el caso de que este en un mismo eje.
			return ((fila != otro.fila) || (columna!=otro.columna));
		}
	};
	

class ComportamientoJugador : public Comportamiento {
  public:
   
    ComportamientoJugador(unsigned int size) : Comportamiento(size) {
		fil = col = 99;
		brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
		posicionVerificada=false;
		contador_pulgarcito=0;
		NFILAS=mapaResultado.size();
		NCOLS=mapaResultado[0].size();
		num_pasos=0;	
		contador_atranque=0;
		calcularRuta=true;
		misionAbortada=false;
		primera_vez=false;
		stop_calculos=0;
		MAX_CALCULOS=3;
		
		
		for(int fil=0;fil<NFILAS;fil++){
			for(int col=0;col<NCOLS;col++){
				mapaResultado[fil][col]='?';
				mapaPulgarcito[fil][col]=-1;
			}
		}
		for(int i=0;i<200;i++){
			for(int j=0;j<200;j++){
				mapaPulgarcito_[i][j]=-1;
				matrizTerreno_[i][j]='?';
			}
		}
		for(int i = 0 ; i<NFILAS ; i++){
			mapaResultado[i][0] = 'P'; 
			mapaResultado[i][1] = 'P';
			mapaResultado[i][2] = 'P';
			mapaResultado[i][(NCOLS-3)] = 'P';
			mapaResultado[i][(NCOLS-2)] = 'P';
			mapaResultado[i][(NCOLS-1)] = 'P';
		}
		for(int i = 0 ; i<NCOLS ; i++){
			mapaResultado[0][i] = 'P';
			mapaResultado[1][i] = 'P';
			mapaResultado[2][i] = 'P';
			mapaResultado[(NFILAS-3)][i] = 'P';
			mapaResultado[(NFILAS-2)][i] = 'P';
			mapaResultado[(NFILAS-1)][i] = 'P';
		}
	}
    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) {
		fil = col = 99;
		brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
		primera_vez=true;
		calcularRuta=false;
		posicionVerificada=true;
		stop_calculos=0;
		MAX_CALCULOS=3;
    }
    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);
    void VisualizaPlan(const estado &st, const list<Action> &plan);
    void PintaPlan(list<Action> plan);
    ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}
    
  
	class nodo {
		public:
			int distancia;
			estado est;
			nodo *padre;
		
			nodo(){}
			nodo (estado e){
				distancia=-1;
				est.fila=e.fila;
				est.columna=e.columna;
				est.orientacion=e.orientacion;
			}
			nodo(estado e , nodo *p){ 
				est.fila=e.fila;
				est.columna=e.columna;
				est.orientacion=e.orientacion;
				padre=p;
				distancia=0;
			}
			nodo(estado e, nodo *p,int dist){
				est.fila=e.fila;
				est.columna=e.columna;
				est.orientacion=e.orientacion;
				padre=p;
				distancia=dist;
			}
			int getFil(){return est.fila;}
			int getCol(){return est.columna;}
			bool operator==(nodo &otro) const;
			bool operator!=(nodo &otro) const;
			bool operator==(const nodo &otro) const;
			bool operator!=(const nodo &otro) const;
			bool operator>(const nodo &otro) const;
			bool operator<(const nodo &otro) const;
			void operator=(const nodo &otro);
	};
  
	struct sortLess {
		bool operator()(nodo const & n1, nodo const & n2) {
			return n1.distancia > n2.distancia;
		}
	};

	
   private:
    int fil, col, brujula;
	list<Action> plan;
    Action accionAnterior;
    bool posicionVerificada ,misionAbortada ,calcularRuta ,primera_vez;
    list<Action> lista_acciones;
    int contador_pulgarcito ,num_pasos,pasos_plan;
    int NFILAS,NCOLS;
	int fil_old ,col_old ,contador_atranque;
	vector< unsigned char> superficie_old; 
	estado ubicacion_anterior;
	int stop_calculos ,MAX_CALCULOS;
	int mov_x[4] = {0,	1,	0,	-1};//Son las posiciones: norte este sur oeste
	int mov_y[4] = {-1,	0,	1,	0};
	
	//Mapas
    int mapaPulgarcito_[200][200];//Aqui guardamos las posiciones no reales, insertando numeros
	unsigned char matrizTerreno_[200][200];//Guardamos las posiciones no reales, segun captemos con los sensores
	int mapaPulgarcito[100][100];//En este guardamos las POSICIONES REALES en modo pulgarcito (es decir , con numeros)
    
    // -----------------------------------------------------------------
    
    bool hayPeligro(const Sensores &sensores, Action accionElegida); 
    bool hayPeligro(const Sensores &sensores); 
    void actualizarBrujula(const Sensores &sensores);
    bool camino_transitable(int fila, int colum);
    pair<bool,int> hayPK(const Sensores &sensores);
    void trazarPlanSimple(int pos);
    Action siguienteAccion();
    bool sincronizandoGPS(const Sensores &sensores);
    Action escogerAccion(const Sensores &sensores);
    void actualizarMapas(const Sensores &sensores);
    void marcar_pasos();
    int izquierda(const Sensores &sensores);
    int derecha(const Sensores &sensores);
    int frontal(const Sensores &sensores);
    int getPosPulgarcito(int y,int x);
    int getPosMapa(int y,int x);
    void desatrancar(const Sensores &sensores);
    bool hayAldeano();
    void esquivarAldeano(const Sensores &sensores,int factor);
    void updateVariablesEstadoAnterior(const Sensores &sensores,Action af);
    void volcadoMapa(int y,int x);
   
    //------- Para la busqueda de objetivos -------
    bool pathFinding(const estado &origen, const estado &destino);
    bool heLlegadoAlDestino(const Sensores &sensores);
    bool NoEsObstaculo(const estado &e);
	int calcularDistancia(estado e1, estado e2);
    void cargarPlan(list<nodo> laruta);
    int calcularOrientacionFilas(int nod_y,int nod_x,int y,int x);
    int calcularOrientacionColums(int nod_y,int nod_x,int y,int x);
    void crearMapaDistancias(estado dest);
    bool destinoConocido(const estado &dest);
    bool destinoAlcanzable(const estado &dest);
    void elevarAtraccionDestino(const estado &destino);
    bool estoyEnPasillo();
    
    //------ Pathfinding experimental -------
    /*
     * Es capaz de localizar un punto muy alejado y con muchos obstaculos.
     * Pero le falta meter en la lista de cerrados , el nodo solucion para que llegue justamente a el.
     * Este algoritmo toma caminos muy irregulares(mejor dicho: muuuuy ineficientes) , pero siempre llega a una solucion.
     * */
    bool pathFindingExperimental(const estado &origen, const estado &destino);
    list<nodo> quitarNodosRedundantes(list<nodo>c);
};

#endif
