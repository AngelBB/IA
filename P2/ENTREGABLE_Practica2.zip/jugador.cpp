/*
 * Alunmo: Angel Barrilao Bensrhir
 * DNI:75170767M
 * Grupo: A3
 * */


#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"
#include <iostream>
#include <cmath>
#include <climits>
#include <utility>
#include <queue>
#include <algorithm> 

void ComportamientoJugador::PintaPlan(list<Action> plan) {
	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
	 
}
void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}
void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}
int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}
/**********************************************************************/
// ************************* CODIGO ESTUDIANTE *************************
/**********************************************************************/
//OFICIALES
void ComportamientoJugador::crearMapaDistancias(estado dest){
	int mapaDistancias[mapaResultado.size()][mapaResultado[0].size()];
	for(int i=0;i<mapaResultado.size();i++){
		for(int j=0;j<mapaResultado[i].size();j++){
			if(camino_transitable(i,j)){
				mapaDistancias[i][j]=calcularDistancia(estado(i,j), dest);
			}else if(mapaResultado[i][j]=='?'){
				mapaDistancias[i][j]=calcularDistancia(estado(i,j), dest);
			}else{
				mapaDistancias[i][j]=50000;
			}
		}
	}
	//En mi ubicacion pongo un numero Grande
	mapaDistancias[fil][col]=800;
}
bool ComportamientoJugador::destinoConocido(const estado &dest){
	return 
	(	(mapaResultado[dest.fila][dest.columna]!='?') 
		&& (mapaResultado[dest.fila+1][dest.columna]!='?'
		|| mapaResultado[dest.fila-1][dest.columna]!='?'
		|| mapaResultado[dest.fila][dest.columna+1]!='?'
		|| mapaResultado[dest.fila][dest.columna-1]!='?')
	);
}
bool ComportamientoJugador::NoEsObstaculo(const estado &e){
	return 
	(	   (mapaResultado[e.fila][e.columna]=='T') 
		|| (mapaResultado[e.fila][e.columna]=='S')
		|| (mapaResultado[e.fila][e.columna]=='K')
	);
}
bool ComportamientoJugador::destinoAlcanzable(const estado &e){
	return 
	(	
		   (mapaResultado[e.fila][e.columna]=='?')   
		|| (mapaResultado[e.fila][e.columna]=='T') 
		|| (mapaResultado[e.fila][e.columna]=='S')
		|| (mapaResultado[e.fila][e.columna]=='K')
	);	
}
int ComportamientoJugador::calcularOrientacionColums(int nod_y,int nod_x,int y,int x){
	if(nod_y == y && nod_x==x-1){
		return 3;//oeste
	}else if((nod_y == y && nod_x==x+1)){
		return 1;//este
	}else{
		return -1;
	}
}
int ComportamientoJugador::calcularOrientacionFilas(int nod_y,int nod_x,int y,int x){
	if(nod_y == y-1 && nod_x==x){
		return 0;//norte
	}else if(nod_y == y+1 && nod_x==x){
		return 2;//sur
	}else{
		return -1;
	}
}
int my_abs(int x){
    int s = x >> 31;
    return (x ^ s) - s;
}
int ComportamientoJugador::calcularDistancia(estado e1, estado e2){
	int resultado = 0;
	resultado=abs(e1.fila-e2.fila) + abs(e1.columna-e2.columna);
    return resultado;
}
bool ComportamientoJugador::nodo::operator==(nodo &n) const{
	return ((est.fila == n.est.fila) && (est.columna==n.est.columna));
}
bool ComportamientoJugador::nodo::operator==(const nodo &n) const{
	return ((est.fila == n.est.fila) && (est.columna==n.est.columna));
}
bool ComportamientoJugador::nodo::operator!=(nodo &n) const{
	return ((est.fila != n.est.fila) && (est.columna!=n.est.columna));
}
bool ComportamientoJugador::nodo::operator!=(const nodo &n) const{
	return ((est.fila != n.est.fila) && (est.columna!=n.est.columna));
}
bool ComportamientoJugador::nodo::operator<(const nodo &n) const{
	return (distancia < n.distancia);
}
bool ComportamientoJugador::nodo::operator>(const nodo &n) const{
	return (distancia > n.distancia);
}
void ComportamientoJugador::nodo::operator=(const nodo &n){
	est.fila=n.est.fila;
	est.columna=n.est.columna;
	padre=n.padre;
	distancia=n.distancia;
}
bool leavingInYourMind(const ComportamientoJugador::nodo &a, const ComportamientoJugador::nodo &b){
	return (a.distancia > b.distancia);
}
bool ComportamientoJugador::pathFinding(const estado &origen, const estado &destino){
	plan.clear();
	list<nodo> lista_padres;
	list<nodo> recorrido;
	queue<nodo> nodos_abiertos;
	nodo inicio(origen,NULL);
	nodos_abiertos.push(inicio);
	
	
	bool visitado[200][200];
	for(int i=0; i<200; i++){
		for(int j=0; j<200; j++){
			visitado[i][j] = false;
		}
	}
	
	visitado[fil][col]=false;
	//~ cout<<"Mi destino: "<<destino.fila<<":"<<destino.columna<<endl;
	
	while(!nodos_abiertos.empty()){
		nodo actual = nodos_abiertos.front();
		lista_padres.push_back(actual);
		nodos_abiertos.pop();
		//~ cout<<actual.est.fila<<":"<<actual.est.columna<<endl;
		
		//Si estamos evaluando el nodo destino paramos el bucle
		if(actual == destino){
			//Creamos la lista de recorrido
			nodo aux = lista_padres.back();
			while(aux.padre != NULL){
				recorrido.push_back(aux);
				aux = *aux.padre;
			}
			break;
		}
		
		//Calculamos los vecinos (N S E OE) (hijos) del nodo  en el tope de la cola ordenada por menor distancia
		//es decir siempre vamos a ir sacando el hijo del mejor nodo por lo que se convierte en el mejor hijo 
		for(int i=0; i<4; i++){
            int fil_aux = mov_x[i] + actual.getFil();
            int col_aux= mov_y[i] + actual.getCol();
            if((camino_transitable(fil_aux,col_aux) && !visitado[fil_aux][col_aux])){ 
				visitado[fil_aux][col_aux] = true;
				nodo hijo(estado(fil_aux,col_aux), &lista_padres.back(),0);
				nodos_abiertos.push(hijo);
			}
        }
	}
	
	if(nodos_abiertos.empty()){
		return false;
	}
	
	//Cargamos el plan en la lista segun la posicion de los nodos
	cargarPlan(recorrido);
	return true;
}		
void ComportamientoJugador::cargarPlan(list<nodo> laruta){
	int fil_nodo,col_nodo;
	int y=fil;
	int x=col;
	int bruju=brujula;
	while(!laruta.empty()){
		fil_nodo=laruta.back().getFil();
		col_nodo=laruta.back().getCol();
		switch (bruju){
            case 0://NORTE
				switch (calcularOrientacionFilas(fil_nodo,col_nodo,y,x)){
					case 0://Norte
						plan.push_back(actFORWARD);
						y--;
					break;
					case 2://Sur
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
						plan.push_back(actFORWARD);
						y++;
					break;
				}
				switch (calcularOrientacionColums(fil_nodo,col_nodo,y,x)){
					case 1://este
						plan.push_back(actTURN_R);
						plan.push_back(actFORWARD);
						bruju = (bruju+1)%4;
						x++;
					break;
					case 3://oeste
						plan.push_back(actTURN_L);
						plan.push_back(actFORWARD);
						bruju = (bruju+3)%4;
						x--;
					break;
				}
			break;
			case 1://ESTE
				switch (calcularOrientacionFilas(fil_nodo,col_nodo,y,x)){
					case 0://Norte
						plan.push_back(actTURN_L);
                        bruju = (bruju+3)%4;
                        plan.push_back(actFORWARD);
                        y--;
					break;
					case 2://Sur
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        y++;
					break;
				}
				switch (calcularOrientacionColums(fil_nodo,col_nodo,y,x)){
					case 1://este
						plan.push_back(actFORWARD);
                        x++;
					break;
					case 3://oeste
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
                        plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        x--;
					break;
				}
			break;
			case 2://SUR
				switch (calcularOrientacionFilas(fil_nodo,col_nodo,y,x)){
					case 0://Norte
						plan.push_back(actTURN_R);
                        bruju = (bruju+1)%4;
                        plan.push_back(actTURN_R);
                        bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        y--;
					break;
					case 2://Sur
						plan.push_back(actFORWARD);
                        y++;
					break;
				}
				switch (calcularOrientacionColums(fil_nodo,col_nodo,y,x)){
					case 1://Este
						plan.push_back(actTURN_L);
                         bruju = (bruju+3)%4;
                        plan.push_back(actFORWARD);
                        x++;
					break;
					case 3://Oeste
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        x--;
					break;
				}
			break;
			case 3://OESTE
				switch (calcularOrientacionFilas(fil_nodo,col_nodo,y,x)){
					case 0://Norte
						plan.push_back(actTURN_R);
						bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        y--;
					break;
					case 2://Sur
						plan.push_back(actTURN_L);
                        bruju = (bruju+3)%4;
                        plan.push_back(actFORWARD);
                        y++;
					break;
				}
				switch (calcularOrientacionColums(fil_nodo,col_nodo,y,x)){
					case 1://este
						plan.push_back(actTURN_R);
                        bruju = (bruju+1)%4;
                        plan.push_back(actTURN_R);
                        bruju = (bruju+1)%4;
                        plan.push_back(actFORWARD);
                        x++;
					break;
					case 3://oeste
						plan.push_back(actFORWARD);
                        x--;
					break;
				}
			break;
		}
        laruta.pop_back();
    }
}
bool ComportamientoJugador::hayPeligro(const Sensores &sensores, Action accionElegida){
	bool ret=false;
	if(!sensores.colision){
		//Si la proxima accion es ir hacia delante y tenemos enfrente terreno infranqueable damos orden que gire por defecto a la derecha
		if((accionElegida==actFORWARD) && (sensores.terreno[2] =='P' || sensores.terreno[2] =='A' || sensores.terreno[2] =='B' || sensores.terreno[2] =='M' || sensores.terreno[2] =='D' || sensores.superficie[2] =='a')){
			ret=true;
		}
	}else{
		ret=true;//Si directamente hemos colisionado saltamos y hacemos true
	}
	return ret;
}
bool ComportamientoJugador::hayPeligro(const Sensores &sensores){
	bool ret=false;
	if(!sensores.colision){
		//Si la proxima accion es ir hacia delante y tenemos enfrente terreno infranqueable damos orden que gire por defecto a la derecha
		if(sensores.terreno[2] =='P' || sensores.terreno[2] =='A' || sensores.terreno[2] =='B' || sensores.terreno[2] =='M' || sensores.terreno[2] =='D' || sensores.superficie[2] =='a'){
			ret=true;
		}
	}else{
		ret=true;//Si directamente hemos colisionado saltamos y hacemos true
	}
	return ret;
}
void ComportamientoJugador::actualizarBrujula(const Sensores &sensores){
	if(!sensores.colision){
		switch(accionAnterior){
			case actFORWARD:
				switch(brujula){
					case 0: //Norte
						fil--;
					break;
					
					case 1: //Oeste
						col++;
					break;
					
					case 2: //Sur
						fil++;
					break;
					
					case 3://Este
						col--;
					break;
				}
				break;
			case actTURN_L:
				brujula = (brujula+3)%4;
				break;
			case actTURN_R:
				brujula = (brujula+1)%4;
				break;
		}
	}
}
bool ComportamientoJugador::camino_transitable(int fila, int colum){
	if(posicionVerificada){
		if(mapaResultado[fila][colum]=='T' || mapaResultado[fila][colum]=='S' || mapaResultado[fila][colum]=='K' || mapaResultado[fila][colum]=='?'){
			return true;
		}
	}else{
		if((matrizTerreno_[fila][colum]=='T' || matrizTerreno_[fila][colum]=='S' || matrizTerreno_[fila][colum]=='K')){
			return true;
		}
	}
	return false;
}
pair<bool,int> ComportamientoJugador::hayPK(const Sensores &sensores){
	pair<bool,int> ret=make_pair(false,-1);
	for(int i=0;i<16;i++){
		if(sensores.terreno[i]=='K'){
			ret=make_pair(true,i);
		}	
	}
	return ret;
}
void ComportamientoJugador::trazarPlanSimple(int pos){
	plan.clear();
	switch(pos){
		case 1: 
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
		break;
		
		case 2:
			plan.push_back(actFORWARD);
		break;
		
		case 3:
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
		break;
		
		case 4:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 5:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
		break;
		
		case 6:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 7:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
		break;
		
		case 8:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 9:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 10:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 11:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_L);
			plan.push_back(actFORWARD);
		break;
		
		case 12:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 13:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
		break;
		
		case 14:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
		
		case 15:
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actTURN_R);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
			plan.push_back(actFORWARD);
		break;
	}
}
Action ComportamientoJugador::siguienteAccion(){
	Action act=actIDLE;
	if(!plan.empty()){
		act=plan.front();
		plan.pop_front();
	}
	return act;
}
bool ComportamientoJugador::sincronizandoGPS(const Sensores &sensores){
	if(sensores.terreno[0]=='K'){
		posicionVerificada=true;
		plan.clear();
		volcadoMapa(sensores.mensajeF,sensores.mensajeC);
		fil=sensores.mensajeF;
		col=sensores.mensajeC;
		return true;
	}
	return false;
}
void ComportamientoJugador::actualizarMapas(const Sensores &sensores){
	if(posicionVerificada){
		mapaResultado[fil][col]=sensores.terreno[0];
		switch(brujula){
			case 0: //Norte
				mapaResultado[fil-1][col-1] = sensores.terreno[1];
				mapaResultado[fil-1][col] = sensores.terreno[2];
				mapaResultado[fil-1][col+1] = sensores.terreno[3];
				mapaResultado[fil-2][col-2] = sensores.terreno[4];
				mapaResultado[fil-2][col-1] = sensores.terreno[5];
				mapaResultado[fil-2][col] = sensores.terreno[6];
				mapaResultado[fil-2][col+1] = sensores.terreno[7];
				mapaResultado[fil-2][col+2] = sensores.terreno[8];
				mapaResultado[fil-3][col-3] = sensores.terreno[9];
				mapaResultado[fil-3][col-2] = sensores.terreno[10];
				mapaResultado[fil-3][col-1] = sensores.terreno[11];
				mapaResultado[fil-3][col] = sensores.terreno[12];
				mapaResultado[fil-3][col+1] = sensores.terreno[13];
				mapaResultado[fil-3][col+2] = sensores.terreno[14];
				mapaResultado[fil-3][col+3] = sensores.terreno[15];
			break;
			
			case 1: //Este
				mapaResultado[fil-1][col+1]=sensores.terreno[1];
				mapaResultado[fil][col+1]=sensores.terreno[2];
				mapaResultado[fil+1][col+1]=sensores.terreno[3];
				mapaResultado[fil-2][col+2]=sensores.terreno[4];
				mapaResultado[fil-1][col+2]=sensores.terreno[5];
				mapaResultado[fil][col+2]=sensores.terreno[6];
				mapaResultado[fil+1][col+2]=sensores.terreno[7];
				mapaResultado[fil+2][col+2]=sensores.terreno[8];
				mapaResultado[fil-3][col+3]=sensores.terreno[9];
				mapaResultado[fil-2][col+3]=sensores.terreno[10];
				mapaResultado[fil-1][col+3]=sensores.terreno[11];
				mapaResultado[fil][col+3]=sensores.terreno[12];
				mapaResultado[fil+1][col+3]=sensores.terreno[13];     
				mapaResultado[fil+2][col+3]=sensores.terreno[14];      
				mapaResultado[fil+3][col+3]=sensores.terreno[15]; 
			break;
			
			case 2: //Sur
				mapaResultado[fil+1][col+1]=sensores.terreno[1];
				mapaResultado[fil+1][col]=sensores.terreno[2];
				mapaResultado[fil+1][col-1]=sensores.terreno[3];
				mapaResultado[fil+2][col+2]=sensores.terreno[4];
				mapaResultado[fil+2][col+1]=sensores.terreno[5];
				mapaResultado[fil+2][col]=sensores.terreno[6];
				mapaResultado[fil+2][col-1]=sensores.terreno[7];
				mapaResultado[fil+2][col-2]=sensores.terreno[8];
				mapaResultado[fil+3][col+3]=sensores.terreno[9];
				mapaResultado[fil+3][col+2]=sensores.terreno[10];
				mapaResultado[fil+3][col+1]=sensores.terreno[11];
				mapaResultado[fil+3][col]=sensores.terreno[12];
				mapaResultado[fil+3][col-1]=sensores.terreno[13];
				mapaResultado[fil+3][col-2]=sensores.terreno[14];
				mapaResultado[fil+3][col-3]=sensores.terreno[15];
			break;
			
			case 3://oeste
			
			mapaResultado[fil+1][col-1]=sensores.terreno[1];
				mapaResultado[fil][col-1]=sensores.terreno[2];
				mapaResultado[fil-1][col-1]=sensores.terreno[3];
				mapaResultado[fil+2][col-2]=sensores.terreno[4];
				mapaResultado[fil+1][col-2]=sensores.terreno[5];
				mapaResultado[fil][col-2]=sensores.terreno[6];
				mapaResultado[fil-1][col-2]=sensores.terreno[7];
				mapaResultado[fil-2][col-2]=sensores.terreno[8];
				mapaResultado[fil+3][col-3]=sensores.terreno[9];
				mapaResultado[fil+2][col-3]=sensores.terreno[10];
				mapaResultado[fil+1][col-3]=sensores.terreno[11];
				mapaResultado[fil][col-3]=sensores.terreno[12];
				mapaResultado[fil-1][col-3]=sensores.terreno[13];
				mapaResultado[fil-2][col-3]=sensores.terreno[14];
				mapaResultado[fil-3][col-3]=sensores.terreno[15];
			
			
				
			break;
		}
	}else{//Mapa temporal
		matrizTerreno_[fil][col]=sensores.terreno[0];
		switch(brujula){
			case 0: //Norte
				matrizTerreno_[fil-1][col-1] = sensores.terreno[1];
				matrizTerreno_[fil-1][col] = sensores.terreno[2];
				matrizTerreno_[fil-1][col+1] = sensores.terreno[3];
				matrizTerreno_[fil-2][col-2] = sensores.terreno[4];
				matrizTerreno_[fil-2][col-1] = sensores.terreno[5];
				matrizTerreno_[fil-2][col] = sensores.terreno[6];
				matrizTerreno_[fil-2][col+1] = sensores.terreno[7];
				matrizTerreno_[fil-2][col+2] = sensores.terreno[8];
				matrizTerreno_[fil-3][col-3] = sensores.terreno[9];
				matrizTerreno_[fil-3][col-2] = sensores.terreno[10];
				matrizTerreno_[fil-3][col-1] = sensores.terreno[11];
				matrizTerreno_[fil-3][col] = sensores.terreno[12];
				matrizTerreno_[fil-3][col+1] = sensores.terreno[13];
				matrizTerreno_[fil-3][col+2] = sensores.terreno[14];
				matrizTerreno_[fil-3][col+3] = sensores.terreno[15];
			break;
			
			case 1: //Oeste
				matrizTerreno_[fil-1][col+1]=sensores.terreno[1];
				matrizTerreno_[fil][col+1]=sensores.terreno[2];
				matrizTerreno_[fil+1][col+1]=sensores.terreno[3];
				matrizTerreno_[fil-2][col+2]=sensores.terreno[4];
				matrizTerreno_[fil-1][col+2]=sensores.terreno[5];
				matrizTerreno_[fil][col+2]=sensores.terreno[6];
				matrizTerreno_[fil+1][col+2]=sensores.terreno[7];
				matrizTerreno_[fil+2][col+2]=sensores.terreno[8];
				matrizTerreno_[fil-3][col+3]=sensores.terreno[9];
				matrizTerreno_[fil-2][col+3]=sensores.terreno[10];
				matrizTerreno_[fil-1][col+3]=sensores.terreno[11];
				matrizTerreno_[fil][col+3]=sensores.terreno[12];
				matrizTerreno_[fil+1][col+3]=sensores.terreno[13];     
				matrizTerreno_[fil+2][col+3]=sensores.terreno[14];      
				matrizTerreno_[fil+3][col+3]=sensores.terreno[15];
			break;
			
			case 2: //Sur
				matrizTerreno_[fil+1][col+1]=sensores.terreno[1];
				matrizTerreno_[fil+1][col]=sensores.terreno[2];
				matrizTerreno_[fil+1][col-1]=sensores.terreno[3];
				matrizTerreno_[fil+2][col+2]=sensores.terreno[4];
				matrizTerreno_[fil+2][col+1]=sensores.terreno[5];
				matrizTerreno_[fil+2][col]=sensores.terreno[6];
				matrizTerreno_[fil+2][col-1]=sensores.terreno[7];
				matrizTerreno_[fil+2][col-2]=sensores.terreno[8];
				matrizTerreno_[fil+3][col+3]=sensores.terreno[9];
				matrizTerreno_[fil+3][col+2]=sensores.terreno[10];
				matrizTerreno_[fil+3][col+1]=sensores.terreno[11];
				matrizTerreno_[fil+3][col]=sensores.terreno[12];
				matrizTerreno_[fil+3][col-1]=sensores.terreno[13];
				matrizTerreno_[fil+3][col-2]=sensores.terreno[14];
				matrizTerreno_[fil+3][col-3]=sensores.terreno[15];
			break;
			
			case 3://Este
			
				matrizTerreno_[fil+1][col-1]=sensores.terreno[1];
				matrizTerreno_[fil][col-1]=sensores.terreno[2];
				matrizTerreno_[fil-1][col-1]=sensores.terreno[3];
				matrizTerreno_[fil+2][col-2]=sensores.terreno[4];
				matrizTerreno_[fil+1][col-2]=sensores.terreno[5];
				matrizTerreno_[fil][col-2]=sensores.terreno[6];
				matrizTerreno_[fil-1][col-2]=sensores.terreno[7];
				matrizTerreno_[fil-2][col-2]=sensores.terreno[8];
				matrizTerreno_[fil+3][col-3]=sensores.terreno[9];
				matrizTerreno_[fil+2][col-3]=sensores.terreno[10];
				matrizTerreno_[fil+1][col-3]=sensores.terreno[11];
				matrizTerreno_[fil][col-3]=sensores.terreno[12];
				matrizTerreno_[fil-1][col-3]=sensores.terreno[13];
				matrizTerreno_[fil-2][col-3]=sensores.terreno[14];
				matrizTerreno_[fil-3][col-3]=sensores.terreno[15];
			
			
				
			break;
		}	
	}
	marcar_pasos();
}
void ComportamientoJugador::marcar_pasos(){
	contador_pulgarcito++;
	if(posicionVerificada){
		mapaPulgarcito[fil][col] = contador_pulgarcito;
	}else{
		mapaPulgarcito_[fil][col] = contador_pulgarcito;
	}
}
int ComportamientoJugador::derecha(const Sensores &sensores){
	switch (brujula){
		case 0://N
			if(camino_transitable(fil,col+1)){
				return getPosPulgarcito(fil,col+1);
			}
			return 50000;
		break;
		case 1://E
			if(camino_transitable(fil+1,col)){
				return getPosPulgarcito(fil+1,col);
			}
			return 50000;
		break;
		case 2://S
			if(camino_transitable(fil,col-1)){
				return getPosPulgarcito(fil,col-1);
			}
			return 50000;
		break;
		case 3://W
			if(camino_transitable(fil-1,col)){
				return getPosPulgarcito(fil-1,col);
			}
			
			return 50000;
		break;
	}
}
int ComportamientoJugador::izquierda(const Sensores &sensores){
	switch (brujula) {
		case 0://N
			if(camino_transitable(fil,col-1)){
				return getPosPulgarcito(fil,col-1);
			}
			return 50000;
		break;
		case 1://E
			if(camino_transitable(fil-1,col)){
				return getPosPulgarcito(fil-1,col);
			}		
			return 50000;
		break;
		case 2://S
			if(camino_transitable(fil,col+1)){
				return getPosPulgarcito(fil,col+1);
			}
			return 50000;
		break;
		case 3://W
			if(camino_transitable(fil+1,col)){
				return getPosPulgarcito(fil+1,col);
			}
					
			return 50000;
		break;
	}
}
int ComportamientoJugador::frontal(const Sensores &sensores){
	switch (brujula) {
		case 0://N
			if(camino_transitable(fil-1,col)){
				return getPosPulgarcito(fil-1,col);
			}
			return 50000;
		break;
		case 1://E
			if(camino_transitable(fil,col+1)){
				return getPosPulgarcito(fil,col+1);
			}
			return 50000;
		break;
		case 2://S
			if(camino_transitable(fil+1,col)){
				return getPosPulgarcito(fil+1,col);
			}
			return 50000;
		break;
		case 3://W
			if(camino_transitable(fil,col-1)){
				return getPosPulgarcito(fil,col-1);
			}
			return 50000;
		break;
	}	
}
int ComportamientoJugador::getPosPulgarcito(int y,int x){
	if(posicionVerificada)
		return mapaPulgarcito[y][x];
	return mapaPulgarcito_[y][x];
}
int ComportamientoJugador::getPosMapa(int y,int x){
	if(posicionVerificada)
		return mapaResultado[y][x];
	return matrizTerreno_[y][x];
}
Action ComportamientoJugador::escogerAccion(const Sensores &sensores){
	Action accion=actFORWARD;//Por defecto siempre iremos hacia delante
	
	//Desatrancamos el personaje si esta rodeado por terreno infranqueable y hay un aldeano haciendo de tapon
	desatrancar(sensores);
	
	//Para evitar colisiones innecesarias controlamos que el aldeano no este frente a nosotros , si lo esta incrementamos el coste de esa casilla y evitamos pasar por ella
	if(sensores.superficie[2]=='a'){ 
		esquivarAldeano(sensores,10);
	}
	
	if(frontal(sensores) < derecha(sensores) && frontal(sensores) < izquierda(sensores)){//frontal el mejor caso
		accion = actFORWARD;
	}else if(izquierda(sensores) < derecha(sensores) && izquierda(sensores) < frontal(sensores)){//izq el mejor  caso
		accion = actTURN_L;
	}else if(derecha(sensores) < izquierda(sensores) && derecha(sensores) < frontal(sensores)){//dcha el mejor caso
		accion = actTURN_R;
	}else if(frontal(sensores) < derecha(sensores)){//Frontal en un caso
		accion = actFORWARD;
	}else if(frontal(sensores) < izquierda(sensores)){
		accion = actFORWARD;
	}else if(derecha(sensores) < frontal(sensores)){//Derecha en un caso
		accion = actTURN_R;
	}else if(derecha(sensores) < izquierda(sensores)){
		accion = actTURN_R;
	}else if(izquierda(sensores) < derecha(sensores)){//Izquierda en un caso
		accion = actTURN_L;
	}else if(izquierda(sensores) < frontal(sensores)){
		accion = actTURN_L;
	}else if((frontal(sensores)==derecha(sensores)) && frontal(sensores) <  izquierda(sensores)){//si front-dcha son menores que izq
		accion =(rand()%2==0)?actFORWARD:actTURN_R;
	}else if((frontal(sensores)==izquierda(sensores)) && frontal(sensores) <  derecha(sensores)){//si front-izq son menores que dcha
		accion =(rand()%2==0)?actFORWARD:actTURN_L;
	}else if((izquierda(sensores)==derecha(sensores)) && izquierda(sensores) <  frontal(sensores)){//si izq-dcha son menores que front
		accion =(rand()%2==0)?actTURN_L:actTURN_R;
	}else if(frontal(sensores) <= -1){//Si todo lo anterior no valida ....
		accion = actFORWARD;
	}else if(izquierda(sensores) <= -1){
		accion = actTURN_L;
	}else if(derecha(sensores) <= -1){
		accion = actTURN_R;
	}else{//Entrara aqui si frente,derecha e izquierda tienen un mismo valor y es grande (50000)
		accion = (static_cast<Action> (rand() % 2 + 1));
		//~ accion = (static_cast<Action> (rand() % 3 + 0));
	}
	
	return accion;
}
void ComportamientoJugador::desatrancar(const Sensores &sensores){
	if((fil_old == fil) && (col_old==col) && hayAldeano() && contador_atranque > 5){
		int norte = getPosPulgarcito(fil-1,col);
		int oeste = getPosPulgarcito(fil,col-1);
		int este = getPosPulgarcito(fil,col+1);
		int sur = getPosPulgarcito(fil+1,col);
		int actual=getPosPulgarcito(fil,col);
		contador_atranque=0;
		
		if(posicionVerificada){
			if((norte!=0) && (norte<actual)){//Vengo del norte (winter is coming)
				mapaPulgarcito[fil][col-1]=50000;//oeste
				mapaPulgarcito[fil][col+1]=50000;//este
				mapaPulgarcito[fil+1][col]=50000;//sur
				contador_atranque=0;
			}else if((sur!=0) && (sur < actual)){//Vengo del sur (ke dise er pixa!)
				mapaPulgarcito[fil][col-1]=50000;//oeste
				mapaPulgarcito[fil][col+1]=50000;//este
				mapaPulgarcito[fil-1][col]=50000;//norte
				contador_atranque=0;
			}else if((oeste!=0) && (oeste < actual)){//El amigo's made in Mexico!
				mapaPulgarcito[fil-1][col]=50000;//norte
				mapaPulgarcito[fil][col+1]=50000;//este
				mapaPulgarcito[fil+1][col]=50000;//sur
				contador_atranque=0;
			}else if((este!=0) && (este<actual)){//Vengo de las indias orientales namaste
				mapaPulgarcito[fil-1][col]=50000;//norte
				mapaPulgarcito[fil][col-1]=50000;//oeste
				mapaPulgarcito[fil+1][col]=50000;//sur
				contador_atranque=0;
			}
		}else{
			if((norte!=0) && (norte<actual)){//Vengo del norte (winter is coming)
				mapaPulgarcito_[fil][col-1]=50000;//oeste
				mapaPulgarcito_[fil][col+1]=50000;//este
				mapaPulgarcito_[fil+1][col]=50000;//sur
				contador_atranque=0;
			}else if((sur!=0) && (sur < actual)){//Vengo del sur (ke dise er pixa!)
				mapaPulgarcito_[fil][col-1]=50000;//oeste
				mapaPulgarcito_[fil][col+1]=50000;//este
				mapaPulgarcito_[fil-1][col]=50000;//norte
				contador_atranque=0;
			}else if((oeste!=0) && (oeste < actual)){//vengo del lejano oeste
				mapaPulgarcito_[fil-1][col]=50000;//norte
				mapaPulgarcito_[fil][col+1]=50000;//este
				mapaPulgarcito_[fil+1][col]=50000;//sur
				contador_atranque=0;
			}else if((este!=0) && (este<actual)){//Vengo de las indias orientales
				mapaPulgarcito_[fil-1][col]=50000;//norte
				mapaPulgarcito_[fil][col-1]=50000;//oeste
				mapaPulgarcito_[fil+1][col]=50000;//sur
				contador_atranque=0;
			}
		}
	}else if((fil_old == fil) && (col_old==col) && hayAldeano()){
		contador_atranque++;
	}else if((fil_old != fil) || (col_old!=col)){
		contador_atranque=0;
	}
}
void ComportamientoJugador::esquivarAldeano(const Sensores &sensores,int factor){
	//if(sensores.superficie[2]=='a'){
		switch (brujula) {
			case 0://N
				if(posicionVerificada){
					int cont_actual=mapaPulgarcito[fil][col];
					mapaPulgarcito[fil-1][col]=cont_actual+factor;
				}else{
					int cont_actual=mapaPulgarcito_[fil][col];
					mapaPulgarcito_[fil-1][col]=cont_actual+factor;
				}
			break;
			
			case 1://e
				if(posicionVerificada){
					int cont_actual=mapaPulgarcito[fil][col];
					mapaPulgarcito[fil][col+1]=cont_actual+factor;
				}else{
					int cont_actual=mapaPulgarcito_[fil][col];
					mapaPulgarcito_[fil][col+1]=cont_actual+factor;
				}
			break;
			
			case 2://S
				if(posicionVerificada){
					int cont_actual=mapaPulgarcito[fil][col];
					mapaPulgarcito[fil+1][col]=cont_actual+factor;
				}else{
					int cont_actual=mapaPulgarcito_[fil][col];
					mapaPulgarcito_[fil+1][col]=cont_actual+factor;
				}
			break;
			
			case 3://W
			if(posicionVerificada){
					int cont_actual=mapaPulgarcito[fil][col];
					mapaPulgarcito[fil][col-1]=cont_actual+factor;
				}else{
					int cont_actual=mapaPulgarcito_[fil][col];
					mapaPulgarcito_[fil][col-1]=cont_actual+factor;
				}
			
				
			break;
		}	
	//}
}
bool ComportamientoJugador::hayAldeano(){
	for(int i=0;i<superficie_old.size();i++){
		if(superficie_old[i]=='a'){
			return true;
		}
	}
	return false;
}
void ComportamientoJugador::updateVariablesEstadoAnterior(const Sensores &sensores,Action af){
	fil_old=fil;
	col_old=col;
	superficie_old=sensores.superficie;
	accionAnterior=af;
	num_pasos++;
}
bool ComportamientoJugador::heLlegadoAlDestino(const Sensores &sensores){
	return ((fil==sensores.destinoF) && (col==sensores.destinoC));
}
void ComportamientoJugador::volcadoMapa(int y,int x){
	int dif_fil = fil - y;
	int dif_col = col - x;
	char auxchar;
	int auxint;
	for(int i=0; i<NFILAS; i++){
		for(int j=0; j<NCOLS; j++){
			auxchar = matrizTerreno_[dif_fil+i][dif_col+j]; 
			auxint = mapaPulgarcito_[dif_fil+i][dif_col+j];
			if(mapaResultado[i][j] =='?')
				mapaResultado[i][j] = auxchar;
			mapaPulgarcito[i][j] += auxint;
			
		}
	}
}
void ComportamientoJugador::elevarAtraccionDestino(const estado &destino){
	mapaPulgarcito[destino.fila][destino.columna]=-2;//TARGET
	/*mapaPulgarcito[destino.fila-1][destino.columna]=-2;//N
	mapaPulgarcito[destino.fila+1][destino.columna]=-2;//S
	mapaPulgarcito[destino.fila][destino.columna+1]=-2;//E
	mapaPulgarcito[destino.fila][destino.columna-1]=-2;//W
	mapaPulgarcito[destino.fila][destino.columna]=-2;//TARGET
	mapaPulgarcito[destino.fila-1][destino.columna]=-1;//N
	mapaPulgarcito[destino.fila+1][destino.columna]=-1;//S
	mapaPulgarcito[destino.fila][destino.columna+1]=-1;//E
	mapaPulgarcito[destino.fila][destino.columna-1]=-1;//W*/
}

bool ComportamientoJugador::estoyEnPasillo(){
	switch (brujula) {
		case 0://N
			return (!camino_transitable(fil,col+1) && !camino_transitable(fil,col-1));
		break;
		
		case 1://E
			return (!camino_transitable(fil+1,col) && !camino_transitable(fil-1,col));
		break;
		
		case 2://S
			return (!camino_transitable(fil,col+1) && !camino_transitable(fil,col-1));
		break;
		
		case 3://W
			return (!camino_transitable(fil+1,col) && !camino_transitable(fil-1,col));
		break;
	}	
}





//NIVEL 3
Action ComportamientoJugador::think(Sensores sensores){ 
	Action accionFinal=actIDLE;
	actualizarBrujula(sensores);//Actualizamos la brujula
	actualizarMapas(sensores);//Actualizamos los mapas ( --->ATENCION: COMENTAR EN NIVELES 1 Y 2 PORQUE DE LO CONTRARIO FALLARA<--- )
	
	//Para nivel 1 y 2
	/** /
	if(primera_vez){
		fil=sensores.mensajeF;
		col=sensores.mensajeC;
		primera_vez=false;
		calcularRuta=true;
		posicionVerificada=true;
	}
	/**/
	
	
	//Si no conocemos nuestra ubicacion
	if(!posicionVerificada){//Si no lo estamos , buscamos alrededor
		if(!sincronizandoGPS(sensores)){//Comprobamos que estamos encima de un PK
			pair<bool,int>parPK=hayPK(sensores);
			if(parPK.first){
				trazarPlanSimple(parPK.second);
			}
		}
	}else{//Si estamos posicionados empezaremos a buscar misiones
		//1. Creamos los estados
		estado origen(fil,col,0);
		estado destino(sensores.destinoF,sensores.destinoC);
		//~ cout<<"Mi destino: "<<destino.fila<<":"<<destino.columna<<endl; 
		
		if(destinoAlcanzable(destino)){
			//2. Miramos si hemos llegado al destino
			if(heLlegadoAlDestino(sensores)){
				calcularRuta=true;//Buscamos otro destino
			}
			
		if(ubicacion_anterior!=destino){
			ubicacion_anterior=destino;
			calcularRuta=true;
		}
		
			//3. Calculamos una ruta
			if(calcularRuta){
				pathFinding(origen,destino);
				//~ PintaPlan(plan);
				calcularRuta=false;
			}
		}
	}
	
	//-------------- Acciones Default -------------
	if(!plan.empty()){//Elegimos entre plan o accion simple
		//Si haciendo el plan encontramos un aldeano nos esperamos
		if(sensores.superficie[2]=='a'){
			if(estoyEnPasillo()){//Si estoy en un pasillo no hago mas que esperar
				plan.push_front(actIDLE);//ponemos en el tope una accion de espera, mientras el aldeano este delante				
			}else{//Si no estoy en un pasillo, giramos y recalculamos
				accionFinal=actTURN_R;
				plan.clear();
				calcularRuta=true;//Volvemos a calcular la ruta
			}
		}else if(plan.front()==actIDLE){//Borramos todos los idles que hay de mas

			while(plan.front()==actIDLE){
							//~ cout<<"hola"<<endl;
				plan.pop_front();
			}
		}else{
			accionFinal=siguienteAccion();
		}
	}else{
		accionFinal=escogerAccion(sensores);
	}
	
	//Comprobamos que la accion no sea peligrosa y la corregimos si es necesario
	if(hayPeligro(sensores,accionFinal)){
		plan.clear();
		accionFinal=actTURN_R;
		calcularRuta=true;//Volvemos a calcular la ruta
	}
	
	
	
	updateVariablesEstadoAnterior(sensores,accionFinal);//Actualizamos las variables que controlan el estado anterior
	return accionFinal;
}
