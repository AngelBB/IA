#include "../Comportamientos_Jugador/jugador.hpp"
#include <iostream>
using namespace std;  


bool ComportamientoJugador::posSinObstaculo(Sensores sensores,char algo){
	switch(algo){
		case 'P':
			return false;
		break;
		
		case 'M':
			return false;
		break;
		
		case 'B':
			if(sensores.objetoActivo != '2'){
				return false;
			}else{
				return true;
			}
		break;
		
		case 'A':
			if(sensores.objetoActivo != '1'){
				return false;
			}else{
				return true;
			}
		break;
		
		default:
			return true;
		break;
	}
}
void ComportamientoJugador::guardarCoordenadasRey(){
	if(!pkEncontrado){//Si estamos bien posicionados
		switch(brujula){
			case 0: //Norte
				coodenadasRey.insert(make_pair(fil,col-1));
			break;
			
			case 1: //Oeste
				coodenadasRey.insert(make_pair(fil+1,col));
			break;
			
			case 2: //Sur
				coodenadasRey.insert(make_pair(fil,col+1));
			break;
			
			case 3://Este
				coodenadasRey.insert(make_pair(fil-1,col));
			break;
		}		
	}
}
int ComportamientoJugador::estimacion_h(int fila, int cols){
	//calculamos H (estimacion desde nuestra pos. actual hasta el destino)
	//Sacamos la coordenada del rey mas cercano
	std::set<pair<int,int>>::iterator it;
	it=coodenadasRey.begin();
	
	int h, aux1=0,
	aux=((*it).first) * 99 + ((*it).second);
	int col_rey,fil_rey;
	
	++it;
	for (it=coodenadasRey.begin(); it!=coodenadasRey.end(); ++it){
		aux1=((*it).first) * 99 + ((*it).second);
		if(aux1 < aux){
			col_rey=(*it).first;
			fil_rey=(*it).second;
			aux=aux1;
		}
	}

	//Calculamos la estimacion
	h = 10*(abs(fila-fil_rey) + abs(cols-col_rey));

	return h;
}
void ComportamientoJugador::calcularCasillaOptima(Sensores sensores){
	
	//Obtenemos las coordenadas de los regalos
	int fil=sensores.regalos[0].first;
	int col=sensores.regalos[0].second;
	
	//calculamos G (el coste de movimiento desde nuestra posicon a la siguiente casilla)
	parGH.push_back(make_pair(14,estimacion_h(fil-1,col-1)));
	parGH.push_back(make_pair(10,estimacion_h(fil-1,col)));
	parGH.push_back(make_pair(14,estimacion_h(fil-1,col+1)));
	parGH.push_back(make_pair(10,estimacion_h(fil,col-1)));
	parGH.push_back(make_pair(-1,-1));
	parGH.push_back(make_pair(10,estimacion_h(fil,col+1)));
	parGH.push_back(make_pair(14,estimacion_h(fil+1,col-1)));
	parGH.push_back(make_pair(10,estimacion_h(fil+1,col)));
	parGH.push_back(make_pair(14,estimacion_h(fil+1,col+1)));
	
	//Calcumos  F (el coste total esto es : H + G)
	/*	
		Ahora tenemos que recorrer parGH y sumar el g y el h
		Comprobamos cual da el F menor y a su vez sacamos el index para poder 
		hacer una ruta con movimientos.
	*/
	int dif=(parGH[0].first + parGH[0].first);
	int pos;
	for(int i=1;i < parGH.size();i++){
		if((dif > (parGH[i].first + parGH[i].first) && i !=4)){
			pos=i;
		}
	}
	
	//Tenemos que validar que la posicion elegida es la correcta
	if (hayObstaculo(sensores,pos)){//Validamos la pos
		movimientoPathFinding(pos);//Trazamos una ruta
	}
}
bool ComportamientoJugador::hayObstaculo(Sensores sensores, int index){
	switch(brujula){
		case 0: //Norte
			switch(index){
				case 0: 
					return (visionJugador(1,sensores));
				break;
				
				case 1:
					return (visionJugador(2,sensores));
				break;
				
				case 2:
					return (visionJugador(3,sensores));
				break;
				
				case 3:
					return (posSinObstaculo(sensores,mapaResultado[fil][col-1]));
				break;
				
				case 5:
					return (posSinObstaculo(sensores,mapaResultado[fil][col+1]));
				break;
				
				case 6:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col-1]));
				break;
				
				case 7:
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col]));
				break;
				
				case 8:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col+1]));
				break;
			}
		break;
		
		case 1: //Oeste
			switch(index){
				case 0: 
					return (visionJugador(3,sensores));
				break;
				
				case 1:
					return (posSinObstaculo(sensores,mapaResultado[fil][col-1]));
				break;
				
				case 2:
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col+1]));
				break;
				
				case 3:
					return (visionJugador(2,sensores));
				break;
				
				case 5:
					return (posSinObstaculo(sensores,mapaResultado[fil][col-1]));
				break;
				
				case 6:
					return (visionJugador(1,sensores));
				break;
				
				case 7:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col]));
				break;
				
				case 8:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col+1]));
				break;
			}
		break;
		
		case 2: //Sur
		switch(index){
				case 0: 
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col-1]));
				break;
				
				case 1:
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col]));
				break;
				
				case 2:
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col+1]));
				break;
				
				case 3:
					return (posSinObstaculo(sensores,mapaResultado[fil][col-1]));
				break;
				
				case 5:
					return (posSinObstaculo(sensores,mapaResultado[fil][col+1]));
				break;
				
				case 6:
					return (visionJugador(3,sensores));
				break;
				
				case 7:
					return (visionJugador(2,sensores));
				break;
				
				case 8:
					return (visionJugador(1,sensores));
				break;
			}
		break;
		
		case 3: //Este
			switch(index){
				case 0: 
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col-1]));
				break;
				
				case 1:
					return (posSinObstaculo(sensores,mapaResultado[fil-1][col]));
				break;
				
				case 2:
					return (visionJugador(1,sensores));
				break;
				
				case 3:
					return (posSinObstaculo(sensores,mapaResultado[fil][col-1]));
				break;
				
				case 5:
					return (visionJugador(2,sensores));
				break;
				
				case 6:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col-1]));
				break;
				
				case 7:
					return (posSinObstaculo(sensores,mapaResultado[fil+1][col]));
				break;
				
				case 8:
					return (visionJugador(3,sensores));
				break;
			}
		break;
	}	
}
void  ComportamientoJugador::movimientoPathFinding(int pos){
	switch(brujula){
		case 0: //Norte
			switch(pos){
				case 0: 
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 1:
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 2:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 3:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 5:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 6:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 7:
					plan.push_back(actTURN_L);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 8:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;

			}
		break;
		
		case 1: //Oeste
			switch(pos){
				case 0: 
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					estoy_ejecutando_plan=true;
				break;
				
				case 1:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 2:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 3:
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 5:
					plan.push_back(actTURN_R);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 6:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					estoy_ejecutando_plan=true;
				break;
				
				case 7:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 8:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
			}
		break;
		
		case 2: //Sur
			switch(pos){
				case 0: 
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 1:
					plan.push_back(actTURN_R);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 2:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 3:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 5:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 6:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 7:
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 8:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
			}
		break;
		
		case 3://Este
			switch(pos){
				case 0: 
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 1:
					plan.push_back(actTURN_L);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 2:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_L);
					estoy_ejecutando_plan=true;
				break;
				
				case 3:
					plan.push_back(actTURN_R);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 5:
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 6:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 7:
					plan.push_back(actTURN_R);
					plan.push_back(actFORWARD);
					estoy_ejecutando_plan=true;
				break;
				
				case 8:
					plan.push_back(actFORWARD);
					plan.push_back(actTURN_R);
					estoy_ejecutando_plan=true;
				break;

			}
		break;
	}	
}
void ComportamientoJugador::pathfinding(Sensores sensores){
	/* ecuacion: F = G + H
		donde:
		
		G = el coste de movimiento para ir desde el punto inicial A a un 
		cierto cuadro de la rejilla, siguiendo el camino generado para llegar allí.
		
		h = el coste de movimiento estimado para ir desde ese cuadro de 
		la rejilla hasta el destino final, el punto B. Esto es a menudo
		nombrado como la heurística.
	 * 
	 * */
	
	
	/* Cuadros verticales - horizontales -> G=10
		Cuadros ortogonales -> G=14  */
	
	//Si tengo un objeto activo
	if(sensores.objetoActivo == '4'){
		calcularCasillaOptima(sensores);
	}
}
Action ComportamientoJugador::irHaciaPuerta(){
	Action accion=actIDLE;
	if(pkEncontrado){
		switch(brujula){
			case 0: //Norte
				//Segun la orientacion , miramos si hay puertas a frente , derecha o izquierda 
				if(mapaResultado[fil-1][col] == 'D'){//Frente
					mapaPulgarcito[fil-1][col]=-1;
					return actGIVE;
				}else if(mapaResultado[fil][col-1] == 'D'){//izq
					return actTURN_L;
				}else if(mapaResultado[fil][col+1] == 'D'){//der
					return actTURN_R;
				}
			break;
			
			case 1: //Oeste
				if(mapaResultado[fil][col-1] == 'D'){
					mapaPulgarcito[fil][col-1];
					return actGIVE;
				}else if(mapaResultado[fil+1][col] == 'D'){
					return actTURN_L;
				}else if(mapaResultado[fil-1][col] == 'D'){
					return actTURN_R;
				}
			break;
			
			case 2: //Sur
				if(mapaResultado[fil+1][col] == 'D'){
					mapaPulgarcito[fil+1][col] = -1;
					return actGIVE;
				}else if(mapaResultado[fil][col+1] == 'D'){
					return actTURN_L;
				}else if(mapaResultado[fil][col-1] == 'D'){
					return actTURN_R;
				}
			break;
			
			case 3://Este
				if(mapaResultado[fil][col+1] == 'D'){
					mapaPulgarcito[fil][col+1] = -1;
					return actGIVE;
				}else if(mapaResultado[fil-1][col] == 'D'){
					return actTURN_L;
				}else if(mapaResultado[fil+1][col] == 'D'){
					return actTURN_R;
				}
			break;
		}
	}else{
		switch(brujula){
			case 0: //Norte
				if(matrizTerreno_[fil_aux-1][col_aux] == 'D'){
					mapaPulgarcito_[fil_aux-1][col_aux] = -1;
					return actGIVE;
				}else if(matrizTerreno_[fil_aux][col_aux-1] == 'D'){
					return actTURN_L;
				}else if(matrizTerreno_[fil_aux][col_aux+1] == 'D'){
					return actTURN_R;
				}
			break;
			
			case 1: //Oeste
				if(matrizTerreno_[fil_aux][col_aux-1] == 'D'){
					mapaPulgarcito_[fil_aux][col_aux-1]=-1;
					return actGIVE;
				}else if(matrizTerreno_[fil_aux+1][col_aux] == 'D'){
					return actTURN_L;
				}else if(matrizTerreno_[fil_aux-1][col_aux] == 'D'){
					return actTURN_R;
				}
			break;
			
			case 2: //Sur
				if(matrizTerreno_[fil_aux+1][col_aux] == 'D'){
					mapaPulgarcito_[fil_aux+1][col_aux] = -1;
					return actGIVE;
				}else if(matrizTerreno_[fil_aux][col_aux+1] == 'D'){
					return actTURN_L;
				}else if(matrizTerreno_[fil_aux][col_aux-1] == 'D'){
					return actTURN_R;
				}
			break;
			
			case 3://Este
				if(matrizTerreno_[fil_aux][col_aux+1] == 'D'){
					mapaPulgarcito_[fil_aux][col_aux+1] = -1;
					return actGIVE;
				}else if(matrizTerreno_[fil_aux-1][col_aux] == 'D'){
					return actTURN_L;
				}else if(matrizTerreno_[fil_aux+1][col_aux] == 'D'){
					return actTURN_R;
				}
			break;
		}
	}
	
	return accion;
}
bool ComportamientoJugador::tengoObjeto(char objeto){
	return (std::binary_search (miMochila.begin(), miMochila.end(), objeto));
}
void ComportamientoJugador::equiparObjeto(char caso,Sensores sensores){
	int pos=-1;
	
	//Recorremos 'mi mochila' y buscamos el objeto adecuado al terreno.
	switch(caso){
		case 'A':
			for(int i=0;((i < miMochila.size()) && (pos != -1));i++){
				if(miMochila[i] == '1'){
					i=pos;
				}
			}
		break;
		
		case 'B':
			for(int i=0;((i < miMochila.size()) && (pos != -1));i++){
				if(miMochila[i] == '2'){
					i=pos;
				}
			}
		break;
		
		case 'D':
			for(int i=0;((i < miMochila.size()) && (pos != -1));i++){
				if(miMochila[i] == '3'){
					i=pos;
				}
			}
		break;
		
		case 'l':
			for(int i=0;((i < miMochila.size()) && (pos != -1));i++){
				if(miMochila[i] == '0'){
					i=pos;
				}
			}
		break;
		
		case 'r':
			for(int i=0;((i < miMochila.size()) && (pos != -1));i++){
				if(miMochila[i] == '4'){
					i=pos;
				}
			}
		break;
	}

	//Trazamos un plan para tratar el objeto
	if(pos != -1){
		for(int i=0;i<pos;i++){
			if(sensores.objetoActivo != '_'){
				acciones_objetos.push_back(actPUSH);
			}
			acciones_objetos.push_back(actPOP);
		}
		plan_objetos=true;
	}
}
bool ComportamientoJugador::colisionConObjeto(Sensores sensores){
	
	switch(sensores.superficie[2]){
		case '0':
			return true;
		break;
		case '1':
			return true;
		break;
		case '2':
			return true;
		break;
		case '3':
			return true;
		break;
		case '4':
			return true;
		break;
		default:
			return false;
		break;
	}
	
	return false;	
}
void ComportamientoJugador::manejadorObjetosExperimental(Sensores sensores){
	///////////////////////
	//Para recoger objeto//
	///////////////////////
	
	if(sensores.colision && colisionConObjeto(sensores)){//Si hemos colisionado con un objeto
		if(sensores.objetoActivo == '_'){//Si no tenemos nada equipado
			acciones_objetos.push_back(actPICKUP);
		}else{//Si tenemos un objeto en la mano
			if(miMochila.size() < 4){ //Si tenemos hueco en la mochila guardamos
				if(!tengoObjeto(sensores.superficie[2]) || sensores.superficie[2] == '4'){//Si el objeto no esta repetido o es un regalo lo guardamos				
					acciones_objetos.push_back(actPUSH);//Guardamos el obj. actual en la mochila
					acciones_objetos.push_back(actPICKUP);//recogemos el nuevo objeto
					miMochila.push_back(sensores.superficie[2]);
					plan_objetos=true;
				}
			}else{//Si la mochila esta llena , descartamos algun objeto
				//Por Prioridad 0 al 4
				if(tengoObjeto('0')){//hueso
					equiparObjeto('0',sensores);
					acciones_objetos.push_back(actPUTDOWN);
					miMochila.erase(std::find(miMochila.begin(),miMochila.end(),'0'));//Borrar objeto MOCHILA
					plan_objetos=true;
				}else if(tengoObjeto('1')){//bikini
					equiparObjeto('1',sensores);
					acciones_objetos.push_back(actPUTDOWN);
					miMochila.erase(std::find(miMochila.begin(),miMochila.end(),'1'));//Borrar objeto MOCHILA
					plan_objetos=true;
				}else if(tengoObjeto('2')){//zapatillas
					equiparObjeto('2',sensores);
					acciones_objetos.push_back(actPUTDOWN);
					miMochila.erase(std::find(miMochila.begin(),miMochila.end(),'2'));//Borrar objeto MOCHILA
					plan_objetos=true;
				}else if(tengoObjeto('3')){//llave
					equiparObjeto('3',sensores);
					acciones_objetos.push_back(actPUTDOWN);
					miMochila.erase(std::find(miMochila.begin(),miMochila.end(),'3'));//Borrar objeto MOCHILA
					plan_objetos=true;
				}else if(tengoObjeto('4')){//regalo
					equiparObjeto('4',sensores);
					acciones_objetos.push_back(actPUTDOWN);
					miMochila.erase(std::find(miMochila.begin(),miMochila.end(),'4'));//Borrar objeto MOCHILA
					plan_objetos=true;
				}
			}
		}
	}else if(!colisionConObjeto(sensores)){//Si no hemos colisionado con un objeto
		
		///////////////////////
		//Para equipar objeto//
		///////////////////////
		
		//Comprobamos que tengamos equipados los objetos correctos segun la situacion,
		//si los tenemos en la mochila , pero no equipados , nos lo equipamos
		if(sensores.superficie[2] == 'l' && sensores.objetoActivo != '0' && tengoObjeto('0')){
			equiparObjeto('0',sensores);//Activara un plan
		}else if(sensores.terreno[2] =='A' && sensores.objetoActivo != '1' && tengoObjeto('1')){
			equiparObjeto('1',sensores);
		}else if(sensores.terreno[2] == 'B' && sensores.objetoActivo != '2' && tengoObjeto('2')){
			equiparObjeto('2',sensores);
		}else if(sensores.terreno[2] == 'D' && sensores.objetoActivo != '3' && tengoObjeto('3')){
			equiparObjeto('3',sensores);
		}else if(sensores.superficie[2] == 'r' && sensores.objetoActivo != '4' && tengoObjeto('4')){
			equiparObjeto('4',sensores);
		}else if((sensores.terreno[2] == 'A' && sensores.objetoActivo == '1') || 
				(sensores.terreno[2] == 'B' && sensores.objetoActivo == '2')){
			acciones_objetos.push_back(actFORWARD);
			plan_objetos=true;
		}else if((sensores.superficie[2] == 'l' && sensores.objetoActivo == '0') || 
				(sensores.superficie[2] == 'r' 	&& sensores.objetoActivo == '4') ||
				(sensores.terreno[2] == 'D' 	&& sensores.objetoActivo == '3')){
			miMochila.erase(std::find(miMochila.begin(),miMochila.end(),sensores.objetoActivo));//Borrar objeto MOCHILA
			acciones_objetos.push_back(actGIVE);
			acciones_objetos.push_back(actFORWARD);
			plan_objetos=true;
		}
	}
	
}
void ComportamientoJugador::objetivosPrioritariosExperimental(Sensores sensores){
	// ACCION PARA IR A UN PUNTO K 
	if(!sensores.colision){
		if(pkEncontrado){
			//Buscamos en que parte de la vision esta el pk
			int posK=-1;
			for(int i=0;i<16;i++){
				if (sensores.terreno[i] == 'K'){
					posK=i;
				}
			}
			
			if(posK != -1 ){
				if(acciones_prioritarias.empty()){//Si hay algun plan , lo borramos , tenemos prioridad por el PK
					acciones_prioritarias.clear();
				}
				trazarPlanPrioritario(posK,true);
			}
		}
		
		int pos=-1;
		//ACCION PARA IR HACIA EL OBJETIVO DE MISION
		if((pos=hayMision(sensores)) != -1){
			if(acciones_prioritarias.empty()){//Si hay algun plan , lo borramos , tenemos prioridad por el rey y sus regalos
				acciones_prioritarias.clear();
			}		
			trazarPlanPrioritario(pos,false);
		}
	}else{
		acciones_prioritarias.clear();
	}	
}
void ComportamientoJugador::calcularAccionExperimental(Sensores sensores){
	Action accion=actIDLE;
	if(!sensores.colision){
		if((delante(1) < derecha(1)) and (delante(1) < izquierda(1))){
			acciones_movimientos.push_back(actFORWARD);
			plan_movimientos=true;
		}else if ( (derecha(1) < delante(1)) and (derecha(1) < izquierda(1) ) ){
			acciones_movimientos.push_back(actTURN_R);
			plan_movimientos=true;
		}else if ((izquierda(1) < derecha(1)) and (izquierda(1) < delante(1) ) ){
			acciones_movimientos.push_back(actTURN_L);
			plan_movimientos=true;
		}else if (delante(1) == -1){
			acciones_movimientos.push_back(actFORWARD);
			plan_movimientos=true;
		}else if(izquierda(1) == -1){
			acciones_movimientos.push_back(actTURN_L);
			plan_movimientos=true;
		}else if(derecha(1) == -1){
			acciones_movimientos.push_back(actTURN_R);
			plan_movimientos=true;
		}else{
			if(rand()%2==0){	
				acciones_movimientos.push_back(actTURN_L);
				plan_movimientos=true;
			}else{
				acciones_movimientos.push_back(actTURN_R);
				plan_movimientos=true;
			}
		}
	}
}
Action ComportamientoJugador::thinkExperimental(Sensores sensores){
//Accion por defecto 
Action accion = actIDLE;


//Actualizamos el estado del la ejecucion
calcularOrientacion(sensores);
rellenarMapas(sensores);
actualizarMapasPulgarcitos(sensores);

//Si nos reseteamos
reset(sensores);




//TOMA DE DECISIONES

	/*manejadorObjetos(sensores);
	objetivosPrioritarios(sensores);*/
	calcularAccion(sensores);



if(!acciones_objetos.empty()){
	//Como el mapa cambia , borro los planes de otras acciones
	//borro prioritarias y movimientos
	acciones_prioritarias.clear();
	acciones_movimientos.clear();
	//cout<<"objetos"<<endl;
		
	accion = acciones_objetos.front();
	acciones_objetos.pop_front();
}else if(!acciones_prioritarias.empty()){
	//Borro planes de objetos y movimientos
	acciones_objetos.clear();
	acciones_movimientos.clear();
	
	//cout<<"prioritarios"<<endl;
	accion = acciones_prioritarias.front();
	acciones_prioritarias.pop_front();
}else if(!acciones_movimientos.empty()){
	//Borro planes de objetos y prioritarias
	acciones_objetos.clear();
	acciones_prioritarias.clear();
	
	//cout<<"movimientos"<<endl;
	accion = acciones_movimientos.front();
	acciones_movimientos.pop_front();
}

if(plan_objetos && acciones_objetos.empty()){
	plan_objetos=false;
}
if(plan_prioritarios && acciones_prioritarias.empty()){
	plan_prioritarios=false;
}
if(plan_movimientos && acciones_movimientos.empty()){
	plan_movimientos=false;
}


if(sensores.terreno[0] == 'K' && pkEncontrado){
	fil=sensores.mensajeF;
	col=sensores.mensajeC;
	int sumaf=fil_aux-sensores.mensajeF;
	int sumac=col_aux-sensores.mensajeC;

	for(int i=0;i<100;i++){
		if(i+sumaf<200){
			for(int j=0;j<100;j++){
				if(j+sumac<200){
					if(mapaResultado[i][j] =='?') mapaResultado[i][j]=matrizTerreno_[i+sumaf][j+sumac];
					if(mapaPulgarcito[i][j]==-1) mapaPulgarcito[i][j]=mapaPulgarcito_[i+sumaf][j+sumac];
				}
			}
		}
	}
	pkEncontrado=false;
}

    ultimaAccion=accion;
	return accion;
	
}
void ComportamientoJugador::trazarPlanPrioritario(int pos,bool una_casilla_mas){
	if(una_casilla_mas){
		switch(pos){
			case 1: 
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 2:
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 3:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 4:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 5:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 6:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 7:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 8:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 9:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 10:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 11:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 12:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 13:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 14:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 15:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
		}
	}else{
		switch(pos){
			case 1: 
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
			break;
			
			case 2:
				acciones_prioritarias.push_back(actIDLE);
			break;
			
			case 3:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
			break;
			
			case 4:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 5:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
			break;
			
			case 6:
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 7:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
			break;
			
			case 8:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 9:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
			break;
			
			case 10:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				
			break;
			
			case 11:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				
			break;
			
			case 12:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				
			break;
			
			case 13:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				
			break;
			
			case 14:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_R);
				acciones_prioritarias.push_back(actFORWARD);
				
			break;
			
			case 15:
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actTURN_L);
				acciones_prioritarias.push_back(actFORWARD);
				acciones_prioritarias.push_back(actFORWARD);
				
			break;
		}
	}
}
bool ComportamientoJugador::visionJugador(int pos,Sensores sensores){
	if(pos >=0 && pos<16){
		if((sensores.terreno[pos] == 'P') || (sensores.terreno[pos] == 'M') ||
		(sensores.terreno[pos] == 'A' && sensores.objetoActivo != '1') ||
		(sensores.terreno[pos] == 'B' && sensores.objetoActivo != '2') ||
		(sensores.superficie[pos] == 'l') || (sensores.superficie[pos] == 'a')){ 
			return false;
		}
	}else if(pos == -1){
		return true;
	}else {
		return false;
	}
	return true;
}


// 

void ComportamientoJugador::reset(Sensores sensores){
	if(sensores.reset){
		ultimaAccion=actIDLE;
		pkEncontrado=true;
		brujula=0;
		fil_aux=100;
		col_aux=100;
		for(int i=0;i<200;i++){
			for(int j=0;j<200;j++){
				matrizTerreno_[i][j]='?';mapaPulgarcito_[i][j]=-1;
			}
		}
	}
}
void ComportamientoJugador::calcularOrientacion(Sensores sensores){
	if(pkEncontrado){
		switch(ultimaAccion){
			case actFORWARD:
				switch(brujula){
					case 0: //Norte
						fil_aux--;
					break;
					
					case 1: //Oeste
						col_aux--;
						
					break;
					
					case 2: //Sur
						fil_aux++;
					break;
					
					case 3: //Este
						col_aux++;
					break;
				}
				break;
			case actTURN_L:
				brujula = (brujula+1)%4;
				
				break;
			case actTURN_R:
				brujula = (brujula+3)%4;
				break;
		}
	}else{
		switch(ultimaAccion){
			case actFORWARD:
				switch(brujula){
					case 0: //Norte
						fil--;
					break;
					
					case 1: //Oeste
						col--;
					break;
					
					case 2: //Sur
						fil++;
					break;
					
					case 3://Este
						col++;
					break;
				}
				break;
			case actTURN_L:
				brujula = (brujula+1)%4;
				break;
			case actTURN_R:
				brujula = (brujula+3)%4;
				break;
		}
	}
}
void ComportamientoJugador::buscarPuerta(Sensores sensores){
	//Buscamos una puerta si tenemos la llave equipada
	if(sensores.objetoActivo == '3'){
		for(int i=0;i<16;i++){
			if(sensores.terreno[i] == 'D'){
				trazarPlan(i);
			}
		}
	}
}
void ComportamientoJugador::rellenarMapas(Sensores sensores){
	if(pkEncontrado){
		matrizTerreno_[fil_aux][col_aux]=sensores.terreno[0];
		
		switch(brujula){
			case 0: //Norte
				for(int i=1;i<4;i++){
					matrizTerreno_[fil_aux-1][col_aux-2+i]=sensores.terreno[i];
				}
				for(int i=4;i<9;i++){
					matrizTerreno_[fil_aux-2][col_aux-6+i]=sensores.terreno[i];
				}
				for(int i=9;i<16;i++){
					matrizTerreno_[fil_aux-3][col_aux-12+i]=sensores.terreno[i];
				}
			break;
			
			case 1: //Oeste
				matrizTerreno_[fil_aux+1][col_aux-1]=sensores.terreno[1];
				matrizTerreno_[fil_aux][col_aux-1]=sensores.terreno[2];
				matrizTerreno_[fil_aux-1][col_aux-1]=sensores.terreno[3];
				
				matrizTerreno_[fil_aux+2][col_aux-2]=sensores.terreno[4];
				matrizTerreno_[fil_aux+1][col_aux-2]=sensores.terreno[5];
				matrizTerreno_[fil_aux][col_aux-2]=sensores.terreno[6];
				matrizTerreno_[fil_aux-1][col_aux-2]=sensores.terreno[7];
				matrizTerreno_[fil_aux-2][col_aux-2]=sensores.terreno[8];
				
				matrizTerreno_[fil_aux+3][col_aux-3]=sensores.terreno[9];
				matrizTerreno_[fil_aux+2][col_aux-3]=sensores.terreno[10];
				matrizTerreno_[fil_aux+1][col_aux-3]=sensores.terreno[11];
				matrizTerreno_[fil_aux][col_aux-3]=sensores.terreno[12];
				matrizTerreno_[fil_aux-1][col_aux-3]=sensores.terreno[13];
				matrizTerreno_[fil_aux-2][col_aux-3]=sensores.terreno[14];
				matrizTerreno_[fil_aux-3][col_aux-3]=sensores.terreno[15];
			break;
			
			case 2: //Sur
				matrizTerreno_[fil_aux+1][col_aux+1]=sensores.terreno[1];
				matrizTerreno_[fil_aux+1][col_aux]=sensores.terreno[2];
				matrizTerreno_[fil_aux+1][col_aux-1]=sensores.terreno[3];

				matrizTerreno_[fil_aux+2][col_aux+2]=sensores.terreno[4];
				matrizTerreno_[fil_aux+2][col_aux+1]=sensores.terreno[5];
				matrizTerreno_[fil_aux+2][col_aux]=sensores.terreno[6];
				matrizTerreno_[fil_aux+2][col_aux-1]=sensores.terreno[7];
				matrizTerreno_[fil_aux+2][col_aux-2]=sensores.terreno[8];

				matrizTerreno_[fil_aux+3][col_aux+3]=sensores.terreno[9];
				matrizTerreno_[fil_aux+3][col_aux+2]=sensores.terreno[10];
				matrizTerreno_[fil_aux+3][col_aux+1]=sensores.terreno[11];
				matrizTerreno_[fil_aux+3][col_aux]=sensores.terreno[12];
				matrizTerreno_[fil_aux+3][col_aux-1]=sensores.terreno[13];
				matrizTerreno_[fil_aux+3][col_aux-2]=sensores.terreno[14];
				matrizTerreno_[fil_aux+3][col_aux-3]=sensores.terreno[15];
			break;
			
			case 3://Este
				matrizTerreno_[fil_aux-1][col_aux+1]=sensores.terreno[1];
				matrizTerreno_[fil_aux][col_aux+1]=sensores.terreno[2];
				matrizTerreno_[fil_aux+1][col_aux+1]=sensores.terreno[3];
				
				matrizTerreno_[fil_aux-2][col_aux+2]=sensores.terreno[4];
				matrizTerreno_[fil_aux-1][col_aux+2]=sensores.terreno[5];
				matrizTerreno_[fil_aux][col_aux+2]=sensores.terreno[6];
				matrizTerreno_[fil_aux+1][col_aux+2]=sensores.terreno[7];
				matrizTerreno_[fil_aux+2][col_aux+2]=sensores.terreno[8];
				
				matrizTerreno_[fil_aux-3][col_aux+3]=sensores.terreno[9];
				matrizTerreno_[fil_aux-2][col_aux+3]=sensores.terreno[10];
				matrizTerreno_[fil_aux-1][col_aux+3]=sensores.terreno[11];
				matrizTerreno_[fil_aux][col_aux+3]=sensores.terreno[12];
				matrizTerreno_[fil_aux+1][col_aux+3]=sensores.terreno[13];     
				matrizTerreno_[fil_aux+2][col_aux+3]=sensores.terreno[14];      
				matrizTerreno_[fil_aux+3][col_aux+3]=sensores.terreno[15];
			break;
		}
	}else{ //Si estamos bien situados , es decir con las posiciones reales, copiamos directamente a 'mapaResultado'
		
		switch(brujula){
			mapaResultado[fil][col]=sensores.terreno[0];
			case 0: //Norte
				for(int i=1;i<4;i++){
					mapaResultado[fil-1][col-2+i]=sensores.terreno[i];
				}
				for(int i=4;i<9;i++){
					mapaResultado[fil-2][col-6+i]=sensores.terreno[i];
				}
				for(int i=9;i<16;i++){
					mapaResultado[fil-3][col-12+i]=sensores.terreno[i];
				}
			break;
			
			case 1: //Oeste
				mapaResultado[fil+1][col-1]=sensores.terreno[1];
				mapaResultado[fil][col-1]=sensores.terreno[2];
				mapaResultado[fil-1][col-1]=sensores.terreno[3];

				mapaResultado[fil+2][col-2]=sensores.terreno[4];
				mapaResultado[fil+1][col-2]=sensores.terreno[5];
				mapaResultado[fil][col-2]=sensores.terreno[6];
				mapaResultado[fil-1][col-2]=sensores.terreno[7];
				mapaResultado[fil-2][col-2]=sensores.terreno[8];

				mapaResultado[fil+3][col-3]=sensores.terreno[9];
				mapaResultado[fil+2][col-3]=sensores.terreno[10];
				mapaResultado[fil+1][col-3]=sensores.terreno[11];
				mapaResultado[fil][col-3]=sensores.terreno[12];
				mapaResultado[fil-1][col-3]=sensores.terreno[13];
				mapaResultado[fil-2][col-3]=sensores.terreno[14];
				mapaResultado[fil-3][col-3]=sensores.terreno[15];
			break;
			
			case 2: //Sur
				mapaResultado[fil+1][col+1]=sensores.terreno[1];
				mapaResultado[fil+1][col]=sensores.terreno[2];
				mapaResultado[fil+1][col-1]=sensores.terreno[3];

				mapaResultado[fil+2][col+2]=sensores.terreno[4];
				mapaResultado[fil+2][col+1]=sensores.terreno[5];
				mapaResultado[fil+2][col]=sensores.terreno[6];
				mapaResultado[fil+2][col-1]=sensores.terreno[7];
				mapaResultado[fil+2][col-2]=sensores.terreno[8];

				mapaResultado[fil+3][col+3]=sensores.terreno[9];
				mapaResultado[fil+3][col+2]=sensores.terreno[10];
				mapaResultado[fil+3][col+1]=sensores.terreno[11];
				mapaResultado[fil+3][col]=sensores.terreno[12];
				mapaResultado[fil+3][col-1]=sensores.terreno[13];
				mapaResultado[fil+3][col-2]=sensores.terreno[14];
				mapaResultado[fil+3][col-3]=sensores.terreno[15];
			break;
			
			case 3://Este
				mapaResultado[fil-1][col+1]=sensores.terreno[1];
				mapaResultado[fil][col+1]=sensores.terreno[2];
				mapaResultado[fil+1][col+1]=sensores.terreno[3];

				mapaResultado[fil-2][col+2]=sensores.terreno[4];
				mapaResultado[fil-1][col+2]=sensores.terreno[5];
				mapaResultado[fil][col+2]=sensores.terreno[6];
				mapaResultado[fil+1][col+2]=sensores.terreno[7];
				mapaResultado[fil+2][col+2]=sensores.terreno[8];

				mapaResultado[fil-3][col+3]=sensores.terreno[9];
				mapaResultado[fil-2][col+3]=sensores.terreno[10];
				mapaResultado[fil-1][col+3]=sensores.terreno[11];
				mapaResultado[fil][col+3]=sensores.terreno[12];
				mapaResultado[fil+1][col+3]=sensores.terreno[13];     
				mapaResultado[fil+2][col+3]=sensores.terreno[14];      
				mapaResultado[fil+3][col+3]=sensores.terreno[15]; 
			break;
		}
	}
}
int ComportamientoJugador::calcularCifraCasilla(int pos,Sensores sensores){
	if(sensores.terreno[pos]=='P' || sensores.terreno[pos]=='M'){
		return 50000;
	}else if(sensores.terreno[pos]=='A' || sensores.terreno[pos]=='B'){
		return (contadorPulgar*10);
	}else if(sensores.superficie[pos]=='l' || sensores.superficie[pos]=='a' || sensores.superficie[pos]=='r'){
		return 50000;
	}else if(sensores.superficie[pos]=='0' || sensores.superficie[pos]=='1' || sensores.superficie[pos]=='2' || sensores.superficie[pos]=='3' || sensores.superficie[pos]=='4'){
		return 50000;
	}else if((sensores.terreno[pos]== 'S' || sensores.terreno[pos]=='T' || sensores.terreno[pos]=='K') && (sensores.superficie[pos]=='_')){
		return -1;
	}else{
		return 5000000;
	}
}
void ComportamientoJugador::actualizarMapasPulgarcitos(Sensores sensores){
	contadorPulgar++;
	if(pkEncontrado){
		mapaPulgarcito_[fil_aux][col_aux]=contadorPulgar;
		switch(brujula){
			case 0: //Norte
				for(int i=1;i<4;i++){
					mapaPulgarcito_[fil_aux-1][col_aux-2+i]=max(calcularCifraCasilla( i,sensores), mapaPulgarcito_[fil_aux-1][col_aux-2+i]);
				}
				for(int i=4;i<9;i++){
					mapaPulgarcito_[fil_aux-2][col_aux-6+i]=max(calcularCifraCasilla( i,sensores), mapaPulgarcito_[fil_aux-2][col_aux-6+i]);
				}
				for(int i=9;i<16;i++){
					mapaPulgarcito_[fil_aux-3][col_aux-12+i]=max(calcularCifraCasilla( i,sensores),mapaPulgarcito_[fil_aux-3][col_aux-12+i]);
				}
			break;
			
			case 1: //Oeste
				mapaPulgarcito_[fil_aux+1][col_aux-1]=max(calcularCifraCasilla( 1,sensores),	mapaPulgarcito_[fil_aux+1][col_aux-1]);
				mapaPulgarcito_[fil_aux][col_aux-1]=max(calcularCifraCasilla( 	2,sensores),  	mapaPulgarcito_[fil_aux][col_aux-1]);
				mapaPulgarcito_[fil_aux-1][col_aux-1]=max(calcularCifraCasilla( 3,sensores),	mapaPulgarcito_[fil_aux-1][col_aux-1]);
				
				mapaPulgarcito_[fil_aux+2][col_aux-2]=max(calcularCifraCasilla( 4,sensores),	mapaPulgarcito_[fil_aux+2][col_aux-2]);
				mapaPulgarcito_[fil_aux+1][col_aux-2]=max(calcularCifraCasilla( 5,sensores),	mapaPulgarcito_[fil_aux+1][col_aux-2]);
				mapaPulgarcito_[fil_aux][col_aux-2]=max(calcularCifraCasilla( 	6,sensores),	mapaPulgarcito_[fil_aux][col_aux-2]);
				mapaPulgarcito_[fil_aux-1][col_aux-2]=max(calcularCifraCasilla( 7,sensores),	mapaPulgarcito_[fil_aux-1][col_aux-2]);
				mapaPulgarcito_[fil_aux-2][col_aux-2]=max(calcularCifraCasilla( 8,sensores),	mapaPulgarcito_[fil_aux-2][col_aux-2]);
				
				mapaPulgarcito_[fil_aux+3][col_aux-3]=max(calcularCifraCasilla( 9,sensores),  	mapaPulgarcito_[fil_aux+3][col_aux-3]);
				mapaPulgarcito_[fil_aux+2][col_aux-3]=max(calcularCifraCasilla( 10,sensores),	mapaPulgarcito_[fil_aux+2][col_aux-3]);
				mapaPulgarcito_[fil_aux+1][col_aux-3]=max(calcularCifraCasilla( 11,sensores),  	mapaPulgarcito_[fil_aux+1][col_aux-3]);
				mapaPulgarcito_[fil_aux][col_aux-3]=max(calcularCifraCasilla( 	12,sensores),	mapaPulgarcito_[fil_aux][col_aux-3]);
				mapaPulgarcito_[fil_aux-1][col_aux-3]=max(calcularCifraCasilla( 13,sensores),	mapaPulgarcito_[fil_aux-1][col_aux-3]);
				mapaPulgarcito_[fil_aux-2][col_aux-3]=max(calcularCifraCasilla( 14,sensores),	mapaPulgarcito_[fil_aux-2][col_aux-3]);
				mapaPulgarcito_[fil_aux-3][col_aux-3]=max(calcularCifraCasilla( 15,sensores),	mapaPulgarcito_[fil_aux-3][col_aux-3]);

			break;
			
			case 2: //Sur
				mapaPulgarcito_[fil_aux+1][col_aux+1]=max(calcularCifraCasilla( 1,sensores),  	mapaPulgarcito_[fil_aux+1][col_aux+1]);
				mapaPulgarcito_[fil_aux+1][col_aux]=max(calcularCifraCasilla( 	2,sensores), 	mapaPulgarcito_[fil_aux+1][col_aux]);
				mapaPulgarcito_[fil_aux+1][col_aux-1]=max(calcularCifraCasilla( 3,sensores),	mapaPulgarcito_[fil_aux+1][col_aux-1]);
				
				mapaPulgarcito_[fil_aux+2][col_aux+2]=max(calcularCifraCasilla( 4,sensores),	mapaPulgarcito_[fil_aux+2][col_aux+2]);
				mapaPulgarcito_[fil_aux+2][col_aux+1]=max(calcularCifraCasilla( 5,sensores),	mapaPulgarcito_[fil_aux+2][col_aux+1]);
				mapaPulgarcito_[fil_aux+2][col_aux]=max(calcularCifraCasilla( 	6,sensores),  	mapaPulgarcito_[fil_aux+2][col_aux]);
				mapaPulgarcito_[fil_aux+2][col_aux-1]=max(calcularCifraCasilla( 7,sensores),  	mapaPulgarcito_[fil_aux+2][col_aux-1]);
				mapaPulgarcito_[fil_aux+2][col_aux-2]=max(calcularCifraCasilla( 8,sensores),	mapaPulgarcito_[fil_aux+2][col_aux-2]);
				
				mapaPulgarcito_[fil_aux+3][col_aux+3]=max(calcularCifraCasilla( 9,sensores),  	mapaPulgarcito_[fil_aux+3][col_aux+3]);
				mapaPulgarcito_[fil_aux+3][col_aux+2]=max(calcularCifraCasilla( 10,sensores),  	mapaPulgarcito_[fil_aux+3][col_aux+2]);
				mapaPulgarcito_[fil_aux+3][col_aux+1]=max(calcularCifraCasilla( 11,sensores),	mapaPulgarcito_[fil_aux+3][col_aux+1]);
				mapaPulgarcito_[fil_aux+3][col_aux]=max(calcularCifraCasilla( 	12,sensores),  	mapaPulgarcito_[fil_aux+3][col_aux]);
				mapaPulgarcito_[fil_aux+3][col_aux-1]=max(calcularCifraCasilla( 13,sensores),	mapaPulgarcito_[fil_aux+3][col_aux-1]);
				mapaPulgarcito_[fil_aux+3][col_aux-2]=max(calcularCifraCasilla( 14,sensores),	mapaPulgarcito_[fil_aux+3][col_aux-2]);
				mapaPulgarcito_[fil_aux+3][col_aux-3]=max(calcularCifraCasilla( 15,sensores), 	mapaPulgarcito_[fil_aux+3][col_aux-3]);
			break;
			
			case 3://Este
				mapaPulgarcito_[fil_aux-1][col_aux+1]=max(calcularCifraCasilla( 1,sensores),	mapaPulgarcito_[fil_aux-1][col_aux+1]);
				mapaPulgarcito_[fil_aux][col_aux+1]=max(calcularCifraCasilla( 	2,sensores),  	mapaPulgarcito_[fil_aux][col_aux+1]);
				mapaPulgarcito_[fil_aux+1][col_aux+1]=max(calcularCifraCasilla( 3,sensores),  	mapaPulgarcito_[fil_aux+1][col_aux+1]);
				
				mapaPulgarcito_[fil_aux-2][col_aux+2]=max(calcularCifraCasilla( 4,sensores),	mapaPulgarcito_[fil_aux-2][col_aux+2]);
				mapaPulgarcito_[fil_aux-1][col_aux+2]=max(calcularCifraCasilla( 5,sensores),	mapaPulgarcito_[fil_aux-1][col_aux+2]);
				mapaPulgarcito_[fil_aux][col_aux+2]=max(calcularCifraCasilla( 	6,sensores),	mapaPulgarcito_[fil_aux][col_aux+2]);
				mapaPulgarcito_[fil_aux+1][col_aux+2]=max(calcularCifraCasilla( 7,sensores),	mapaPulgarcito_[fil_aux+1][col_aux+2]);
				mapaPulgarcito_[fil_aux+2][col_aux+2]=max(calcularCifraCasilla( 8,sensores),	mapaPulgarcito_[fil_aux+2][col_aux+2]);
				
				mapaPulgarcito_[fil_aux-3][col_aux+3]=max(calcularCifraCasilla( 9,sensores),  	mapaPulgarcito_[fil_aux-3][col_aux+3]);
				mapaPulgarcito_[fil_aux-2][col_aux+3]=max(calcularCifraCasilla( 10,sensores),	mapaPulgarcito_[fil_aux-2][col_aux+3]);
				mapaPulgarcito_[fil_aux-1][col_aux+3]=max(calcularCifraCasilla( 11,sensores),	mapaPulgarcito_[fil_aux-1][col_aux+3]);
				mapaPulgarcito_[fil_aux][col_aux+3]=max(calcularCifraCasilla( 	12,sensores),	mapaPulgarcito_[fil_aux][col_aux+3]);
				mapaPulgarcito_[fil_aux+1][col_aux+3]=max(calcularCifraCasilla( 13,sensores),	mapaPulgarcito_[fil_aux+1][col_aux+3]);
				mapaPulgarcito_[fil_aux+2][col_aux+3]=max(calcularCifraCasilla( 14,sensores),	mapaPulgarcito_[fil_aux+2][col_aux+3]);
				mapaPulgarcito_[fil_aux+3][col_aux+3]=max(calcularCifraCasilla( 15,sensores),	mapaPulgarcito_[fil_aux+3][col_aux+3]);
			break;
		}
	}else{
		mapaPulgarcito[fil][col]=contadorPulgar;
		switch(brujula){
			case 0: //Norte
				for(int i=1;i<4;i++){
					mapaPulgarcito[fil-1][col-2+i]=max(calcularCifraCasilla( i,sensores),mapaPulgarcito[fil-1][col-2+i]);
				}
				for(int i=4;i<9;i++){
					mapaPulgarcito[fil-2][col-6+i]=max(calcularCifraCasilla( i,sensores), mapaPulgarcito[fil-2][col-6+i]);
				}
				for(int i=9;i<16;i++){
					mapaPulgarcito[fil-3][col-12+i]=max(calcularCifraCasilla( i,sensores),mapaPulgarcito[fil-3][col-12+i]);
				}
  			break;
			
			case 1: //Oeste
				mapaPulgarcito[fil+1][col-1]=max(calcularCifraCasilla( 	1,sensores),	mapaPulgarcito[fil+1][col-1]);
				mapaPulgarcito[fil][col-1]=max(calcularCifraCasilla( 	2,sensores),  	mapaPulgarcito[fil][col-1]);
				mapaPulgarcito[fil-1][col-1]=max(calcularCifraCasilla( 	3,sensores),	mapaPulgarcito[fil-1][col-1]);
				
				mapaPulgarcito[fil+2][col-2]=max(calcularCifraCasilla( 	4,sensores),	mapaPulgarcito[fil+2][col-2]);
				mapaPulgarcito[fil+1][col-2]=max(calcularCifraCasilla( 	5,sensores),	mapaPulgarcito[fil+1][col-2]);
				mapaPulgarcito[fil][col-2]=max(calcularCifraCasilla( 	6,sensores),	mapaPulgarcito[fil][col-2]);
				mapaPulgarcito[fil-1][col-2]=max(calcularCifraCasilla( 	7,sensores),	mapaPulgarcito[fil-1][col-2]);
				mapaPulgarcito[fil-2][col-2]=max(calcularCifraCasilla( 	8,sensores),	mapaPulgarcito[fil-2][col-2]);
				
				mapaPulgarcito[fil+3][col-3]=max(calcularCifraCasilla( 	9,sensores), 	mapaPulgarcito[fil+3][col-3]);
				mapaPulgarcito[fil+2][col-3]=max(calcularCifraCasilla( 	10,sensores),	mapaPulgarcito[fil+2][col-3]);
				mapaPulgarcito[fil+1][col-3]=max(calcularCifraCasilla( 	11,sensores),  	mapaPulgarcito[fil+1][col-3]);
				mapaPulgarcito[fil][col-3]=max(calcularCifraCasilla( 	12,sensores),	mapaPulgarcito[fil][col-3]);
				mapaPulgarcito[fil-1][col-3]=max(calcularCifraCasilla( 	13,sensores),	mapaPulgarcito[fil-1][col-3]);
				mapaPulgarcito[fil-2][col-3]=max(calcularCifraCasilla( 	14,sensores),	mapaPulgarcito[fil-2][col-3]);
				mapaPulgarcito[fil-3][col-3]=max(calcularCifraCasilla( 	15,sensores),	mapaPulgarcito[fil-3][col-3]);

			break;
			
			case 2: //Sur
				mapaPulgarcito[fil+1][col+1]=max(calcularCifraCasilla( 	1,sensores),  	mapaPulgarcito[fil+1][col+1]);
				mapaPulgarcito[fil+1][col]=max(calcularCifraCasilla( 	2,sensores),  	mapaPulgarcito[fil+1][col]);
				mapaPulgarcito[fil+1][col-1]=max(calcularCifraCasilla( 	3,sensores),	mapaPulgarcito[fil+1][col-1]);
				
				mapaPulgarcito[fil+2][col+2]=max(calcularCifraCasilla( 	4,sensores),	mapaPulgarcito[fil+2][col+2]);
				mapaPulgarcito[fil+2][col+1]=max(calcularCifraCasilla( 	5,sensores),	mapaPulgarcito[fil+2][col+1]);
				mapaPulgarcito[fil+2][col]=max(calcularCifraCasilla( 	6,sensores),	mapaPulgarcito[fil+2][col]);
				mapaPulgarcito[fil+2][col-1]=max(calcularCifraCasilla( 	7,sensores),  	mapaPulgarcito[fil+2][col-1]);
				mapaPulgarcito[fil+2][col-2]=max(calcularCifraCasilla( 	8,sensores),	mapaPulgarcito[fil+2][col-2]);
				
				mapaPulgarcito[fil+3][col+3]=max(calcularCifraCasilla( 	9,sensores), 	mapaPulgarcito[fil+3][col+3]);
				mapaPulgarcito[fil+3][col+2]=max(calcularCifraCasilla( 	10,sensores),	mapaPulgarcito[fil+3][col+2]);
				mapaPulgarcito[fil+3][col+1]=max(calcularCifraCasilla( 	11,sensores),	mapaPulgarcito[fil+3][col+1]);
				mapaPulgarcito[fil+3][col]=max(calcularCifraCasilla( 	12,sensores),	mapaPulgarcito[fil+3][col]);
				mapaPulgarcito[fil+3][col-1]=max(calcularCifraCasilla( 	13,sensores),	mapaPulgarcito[fil+3][col-1]);
				mapaPulgarcito[fil+3][col-2]=max(calcularCifraCasilla( 	14,sensores),	mapaPulgarcito[fil+3][col-2]);
				mapaPulgarcito[fil+3][col-3]=max(calcularCifraCasilla( 	15,sensores),  	mapaPulgarcito[fil+3][col-3]);
			break;
			
			case 3://Este
				mapaPulgarcito[fil-1][col+1]=max(calcularCifraCasilla( 	1,sensores),	mapaPulgarcito[fil-1][col+1]);
				mapaPulgarcito[fil][col+1]=max(calcularCifraCasilla( 	2,sensores),  	mapaPulgarcito[fil][col+1]);
				mapaPulgarcito[fil+1][col+1]=max(calcularCifraCasilla( 	3,sensores),  	mapaPulgarcito[fil+1][col+1]);
				
				mapaPulgarcito[fil-2][col+2]=max(calcularCifraCasilla( 	4,sensores),	mapaPulgarcito[fil-2][col+2]);
				mapaPulgarcito[fil-1][col+2]=max(calcularCifraCasilla( 	5,sensores),	mapaPulgarcito[fil-1][col+2]);
				mapaPulgarcito[fil][col+2]=max(calcularCifraCasilla( 	6,sensores),	mapaPulgarcito[fil][col+2]);
				mapaPulgarcito[fil+1][col+2]=max(calcularCifraCasilla( 	7,sensores),	mapaPulgarcito[fil+1][col+2]);
				mapaPulgarcito[fil+2][col+2]=max(calcularCifraCasilla( 	8,sensores),	mapaPulgarcito[fil+2][col+2]);
				
				mapaPulgarcito[fil-3][col+3]=max(calcularCifraCasilla( 	9,sensores),  	mapaPulgarcito[fil-3][col+3]);
				mapaPulgarcito[fil-2][col+3]=max(calcularCifraCasilla( 	10,sensores),	mapaPulgarcito[fil-2][col+3]);
				mapaPulgarcito[fil-1][col+3]=max(calcularCifraCasilla( 	11,sensores),	mapaPulgarcito[fil-1][col+3]);
				mapaPulgarcito[fil][col+3]=max(calcularCifraCasilla( 	12,sensores),	mapaPulgarcito[fil][col+3]);	
				mapaPulgarcito[fil+1][col+3]=max(calcularCifraCasilla( 	13,sensores),	mapaPulgarcito[fil+1][col+3]);
				mapaPulgarcito[fil+2][col+3]=max(calcularCifraCasilla( 	14,sensores),	mapaPulgarcito[fil+2][col+3]);
				mapaPulgarcito[fil-3][col+3]=max(calcularCifraCasilla( 	15,sensores),	mapaPulgarcito[fil+3][col+3]);
			break;
		}
	}
}
int ComportamientoJugador::delante(int n){
	if(pkEncontrado){
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito_[fil_aux-n][col_aux];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito_[fil_aux][col_aux-n];
			break;
			
			case 2: //Sur
				return mapaPulgarcito_[fil_aux+n][col_aux];
			break;
			
			case 3: //Este
				return mapaPulgarcito_[fil_aux][col_aux+n];
			break;
		}	
	}else{
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito[fil-n][col];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito[fil][col-n];
			break;
			
			case 2: //Sur
				return mapaPulgarcito[fil+n][col];
			break;
			
			case 3://Este
				return mapaPulgarcito[fil][col+n];
			break;
		}		
	}
}
int ComportamientoJugador::derecha(int n){
	if(pkEncontrado){
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito_[fil_aux][col_aux+n];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito_[fil_aux+n][col_aux];
			break;
			
			case 2: //Sur
				return mapaPulgarcito_[fil_aux][col_aux-n];
			break;
			
			case 3://Este
				return mapaPulgarcito_[fil_aux-n][col_aux];
			break;
		}	
	}else{
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito[fil][col+n];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito[fil+n][col];
			break;
			
			case 2: //Sur
				return mapaPulgarcito[fil][col-n];
			break;
			
			case 3://Este
				return mapaPulgarcito[fil-n][col];
			break;
		}		
	}
}
int ComportamientoJugador::izquierda(int n){
	if(pkEncontrado){
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito_[fil_aux][col_aux-n];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito_[fil_aux+n][col_aux];
			break;
			
			case 2: //Sur
				return mapaPulgarcito_[fil_aux][col_aux+n];
			break;
			
			case 3://Este
				return mapaPulgarcito_[fil_aux-n][col_aux];
			break;
		}	
	}else{
		switch(brujula){
			case 0: //Norte
				return mapaPulgarcito[fil][col-n];
			break;
			
			case 1: //Oeste
				return mapaPulgarcito[fil+n][col];
			break;
			
			case 2: //Sur
				return mapaPulgarcito[fil][col+n];
			break;
			
			case 3://Este 
				return mapaPulgarcito[fil-n][col];
			break;
		}		
	}
}
int ComportamientoJugador::indexMenorElemento(vector<int> v){
    int index = 0;

    for(int i = 1; i < v.size(); i++)
    {
        if(v[i] < v[index])
            index = i;              
    }

    return index;
}
void ComportamientoJugador::trazarPlan(int pos){

	if(pos>0 && pos<=2){
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_L);
		estoy_ejecutando_plan=true;
	}else if(pos>=2 && pos<4){
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_R);
		estoy_ejecutando_plan=true;
	}else if(pos<=6 && pos>3){
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_L);
		estoy_ejecutando_plan=true;
	}else if(pos>=6 && pos<9){
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_R);
		estoy_ejecutando_plan=true;
	}else if(pos<=12 && pos>8){
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_L);
		estoy_ejecutando_plan=true;
	}else if(pos>=12 && pos<16){
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actFORWARD);
		plan.push_back(actTURN_R);
		estoy_ejecutando_plan=true;
	}else{
		estoy_ejecutando_plan=true;
		if(rand()%2==0){
			plan.push_back(actFORWARD);
		}else{
			plan.push_back(actTURN_R);								
		}
	}
}
Action ComportamientoJugador::manejadorObjetos(Sensores sensores){
	
	if(ultimaAccion==actGIVE){
		return actFORWARD;
	}
	if(sensores.objetoActivo=='0' || sensores.objetoActivo=='1' || sensores.objetoActivo=='2' || sensores.objetoActivo=='3'){
		tiempolimiteobjeto++;
		if(tiempolimiteobjeto>=200 && (sensores.terreno[0]=='S' || sensores.terreno[0]=='T')){
			tiempolimiteobjeto=0;
			return actTHROW;
		}
	}
	if(sensores.objetoActivo == '_' && (sensores.superficie[2] == '0' || sensores.superficie[2]=='1' || sensores.superficie[2]=='2' || sensores.superficie[2]=='3' || sensores.superficie[2]=='4')){
		return actPICKUP;
	}
	if((sensores.superficie[2]=='l' && sensores.objetoActivo=='0') || (sensores.superficie[2]=='r' && sensores.objetoActivo=='4')){
		return actGIVE;
	}
	if(sensores.terreno[2] == 'A' && sensores.objetoActivo == '1'){
		return actFORWARD;
	}
	if(sensores.terreno[2] == 'B' && sensores.objetoActivo == '2'){
		return actFORWARD;
	}
	if(sensores.terreno[2] == 'D' && sensores.objetoActivo == '3'){
		return actGIVE;
	}
	
	return actIDLE;
}
Action ComportamientoJugador::calcularAccion(Sensores sensores){
	Action accion=actIDLE;
	
	//Actualizamos el estado del la ejecucion
	calcularOrientacion(sensores);
	rellenarMapas(sensores);
	actualizarMapasPulgarcitos(sensores);

	
	///////////
	//OBJETOS//
	///////////
	
	if ((accion=manejadorObjetos(sensores)) != actIDLE){
		return accion;
	}
	if(sensores.objetoActivo == '3'){
		buscarPuerta(sensores);
	}
	
	//////////////
	//MOVIMIENTO//
	//////////////
	if(!sensores.colision){
		//Primero vamos a por los objetivos prioritarios
		objetivosPrioritarios(sensores);
		if(!estoy_ejecutando_plan){//Si no estamos siguiendo un plan , seremos reactivos
			if((delante(1) < derecha(1)) and (delante(1) < izquierda(1))){
				accion = actFORWARD;
			}else if ( (derecha(1) < delante(1)) and (derecha(1) < izquierda(1) ) ){
				accion = actTURN_R;
			}else if ((izquierda(1) < derecha(1)) and (izquierda(1) < delante(1) ) ){
				accion = actTURN_L;
			}else if (delante(1) == -1){
				accion = actFORWARD;
			}else if(izquierda(1) == -1){
				accion = actTURN_L;
			}else if(derecha(1) == -1){
				accion = actTURN_R;
			}else{
				if(rand()%2==0){	
					accion = actTURN_L ;
				}else{
					accion = actTURN_R ;
				}
			}
		}else if(estoy_ejecutando_plan && !plan.empty()){//Si hay un plan activado
			accion = plan.front();
			plan.pop_front();
		}else if(estoy_ejecutando_plan && plan.empty()){
			estoy_ejecutando_plan=false;
		}
	}

	return accion;
}
int ComportamientoJugador::hayMision(Sensores sensores){
	int pos=-1;
	for(int i=0;i<16;i++){
		if(((sensores.superficie[i] == 'r') && sensores.objetoActivo=='4') || sensores.superficie[i] == '4'){
			pos=i;
		}
	}
	return pos;
}
void ComportamientoJugador::objetivosPrioritarios(Sensores sensores){
	// ACCION PARA IR A UN PUNTO K 
	if(pkEncontrado){
		//Buscamos en que parte de la vision esta el pk
		int posK=-1;
		for(int i=0;i<16;i++){
			if (sensores.terreno[i] == 'K'){
				posK=i;
			}
		}
		
		if(posK != -1 ){
			if(plan.empty()){//Si hay algun plan , lo borramos , tenemos prioridad por el PK
				plan.clear();
			}
			trazarPlan(posK);
		}
	}
	
	int pos=-1;
	//ACCION PARA IR HACIA EL OBJETIVO DE MISION
	if((pos=hayMision(sensores)) != -1){
		if(plan.empty()){//Si hay algun plan , lo borramos , tenemos prioridad por el rey y sus regalos
			plan.clear();
		}		
		trazarPlan(pos);
	}
}
Action ComportamientoJugador::think(Sensores sensores){
//Accion por defecto 
Action accion = actIDLE;

//Si nos reseteamos
reset(sensores);


if(!sensores.colision){
	accion=calcularAccion(sensores);
}else if(sensores.colision){
	if(rand()%2==0){	
		accion = actTURN_L ;
	}else{
		accion = actTURN_R ;
	}
}

if(sensores.terreno[0] == 'K' && pkEncontrado){
	fil=sensores.mensajeF;
	col=sensores.mensajeC;
	int sumaf=fil_aux-sensores.mensajeF;
	int sumac=col_aux-sensores.mensajeC;

	for(int i=0;i<100;i++){
		if(i+sumaf<200){
			for(int j=0;j<100;j++){
				if(j+sumac<200){
					if(mapaResultado[i][j] =='?') mapaResultado[i][j]=matrizTerreno_[i+sumaf][j+sumac];
					if(mapaPulgarcito[i][j]==-1) mapaPulgarcito[i][j]=mapaPulgarcito_[i+sumaf][j+sumac];
				}
			}
		}
	}
	pkEncontrado=false;
}

    ultimaAccion=accion;
	return accion;
	
}


int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}
