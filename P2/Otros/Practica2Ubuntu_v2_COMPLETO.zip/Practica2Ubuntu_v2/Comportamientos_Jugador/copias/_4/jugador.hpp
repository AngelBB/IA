#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"
#include <algorithm>
#include <vector>
#include <list>
#include <string>
using namespace std;

class ComportamientoJugador : public Comportamiento{
  
  
  /***** VARIABLES *****/
  private:
    
    //Ubicacion
	int fil, col;//Para los mapas reales
	int fil_aux,col_aux;//Para los mapas ficticios
	int brujula;//Para la orientacion del mapa
	bool pkEncontrado;//Para indicar si estamos bien orientados con respecto al mapa real
	
	//Para tomar objetos
	bool tomar_objeto, activar_objeto, contObj;
  
	//Mapas auxiliares - matrices
	int mapaPulgarcito_[200][200];//Aqui guardamos las posiciones no reales, insertando numeros
	unsigned char matrizTerreno_[200][200];//Guardamos las posiciones no reales, segun captemos con los sensores
	int mapaPulgarcito[100][100];//En este guardamos las POSICIONES REALES en modo pulgarcito (es decir , con numeros)
	int contadorPulgar=0;
	int tiempolimiteobjeto=0;
	int tiempo=0;
  
	//Acciones
	Action ultimaAccion;
	bool estoy_ejecutando_plan = false;
	bool error_plan = false;
	list<Action>plan;
	
	bool colision;
	int pasoporpuerta=0;
	bool principio=true; 
	
	
		
    
  /***** METODOS *****/
  public:
	//Constructor
    ComportamientoJugador(unsigned int size) : Comportamiento(size){
		
		//----Inicializar Variables de Estado----
		fil=50;
		col=50;
		fil_aux=100;
		col_aux=100;
		brujula=0; // 0: Norte, 1: Este, 2: Sur, 3: Oeste
		ultimaAccion=actIDLE;//Ultima accion sin hacer nada por defecto
		/*girar_derecha=false;
		girar_izquierda=false;
		bien_situado=false;
		num_pasos=0;
		contObj=0;*/
		tiempolimiteobjeto=0;
		pkEncontrado=true;
			
		
		//---- Inizializar mapaResultado ----
		for(int i=0;i<100;i++){
			for(int j=0;j<100;j++){
				mapaResultado[i][j]='?';
				mapaPulgarcito[i][j]=-1;
			}
		}
		
		//---- Inicializar variables pulgarcito ----
		tiempo=0;
		//Rellenamos mapa pulgarcito con valor 0
		for(int i=0;i<200;i++){
			for(int j=0;j<200;j++){
				mapaPulgarcito_[i][j]=-1;
				matrizTerreno_[i][j]='?';
			}
		}
		
		
		//---- Meter precipicios ---- 
		for(int i = 0 ; i<100 ; i++){
			mapaResultado[i][0] = 'P'; 
			mapaResultado[i][1] = 'P';
			mapaResultado[i][2] = 'P';

			mapaResultado[i][97] = 'P';
			mapaResultado[i][98] = 'P';
			mapaResultado[i][99] = 'P';
		}

		for(int i = 0 ; i<100 ; i++){
			mapaResultado[0][i] = 'P';
			mapaResultado[1][i] = 'P';
			mapaResultado[2][i] = 'P';

			mapaResultado[97][i] = 'P';
			mapaResultado[98][i] = 'P';
			mapaResultado[99][i] = 'P';
		}
	}

	//POR DEFECTO
    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}
	ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}
    Action think(Sensores sensores);
    int interact(Action accion, int valor);
	

	//NUEVOS
	void reset(Sensores sensores);
	Action rastrearPK(Sensores sensores);
	void calcularOrientacion(Sensores sensores);
	Action calcularAccion(Sensores sensores);
	void calcularRuta(int opcion);
	void rellenarMapas(Sensores sensores);
	int calcularCifraCasilla(int pos,Sensores sensores);
	void actualizarMapasPulgarcitos(Sensores sensores);
	bool caminoDespejado(Sensores sensores);
	int derecha(int n);
	int izquierda(int n);
	int delante(int n);
	int indexMenorElemento(vector<int> v);
	void trazarPlan(int pos);
	int hayMision(Sensores sensores);
	void objetivosPrioritarios(Sensores sensores);
	void meterPrecipicio();
	Action irHaciaPuerta();
	void buscarPuerta(Sensores sensores);
	void completar();
	Action manejadorObjetos(Sensores sensores);
	
};


#endif
