#ifndef PIERNAREY3D_HPP
#define PIERNAREY3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class PiernaRey3D : public Objeto3D{
private:

public:
  PiernaRey3D();
  ~PiernaRey3D();

};

#endif
