#ifndef LEO3D_HPP
#define LEO3D_HPP

#include "modelos/leo/torso.hpp"
#include "obj3dlib.hpp"
#include <string.h>


class Leo3D : public Objeto3D{
private:

public:
  Leo3D();
  ~Leo3D();

};

#endif
