#ifndef CINTURALEO3D_HPP
#define CINTURALEO3D_HPP

#include "obj3dlib.hpp"
#include "modelos/leo/pierna.hpp"
#include <string.h>


class CinturaLeo3D : public Objeto3D{
private:

public:
  CinturaLeo3D();
  ~CinturaLeo3D(){}

};

#endif
