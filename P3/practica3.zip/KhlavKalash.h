/*
 * Alumno: Angel Barrilao Bensrhir
 * Grupo: A3
 */
// Basado en Mancala.cpp
#include "Bot.h"
#include <limits>
#include <list>

#ifndef MANUPCBOT_H_
#define MANUPCBOT_H_

const int MAX_INT=numeric_limits<int>::max();
const int MIN_INT=numeric_limits<int>::min();

struct Nodo{
    GameState state;
    Move move;
};

class KhlavKalash:Bot {
public:
	KhlavKalash();
	~KhlavKalash();
	void initialize();
	string getName();
	Move nextMove(const vector<Move> &adversary, const GameState &state);

	//Metodos
	void whoami();
	Move elegirMovimiento();
	pair<int,Move> AB_Minimax(const GameState &n,int alfa,int beta,Player ply,int profundidad);
	int findacross(int ending);
	int	totalSemillas(const Player &p,const GameState &state);
	int heuristica(const GameState &state);
	int numero_turnos(Player p,const GameState &state);
  int numero_turnos(const GameState &state);
	int getPosOponente(int pos);
	int puntos_de_robo(Player p,int valorTablero,const GameState &state);
  int puntos_de_robo(int valorTablero,const GameState &state);


	//Variables
	int nodos,maxnodos,contTurnos,profundidad;
	bool primeraEjecucion;
	Player yo,otro;


	float puntos_de_roboAlt(float valorTablero,const GameState &state);
	float totalSemillasAlt(const Player &p,const GameState &state);
	int heuristica_especial(const GameState &state);

};

#endif /* MANUPCBOT_H_ */
