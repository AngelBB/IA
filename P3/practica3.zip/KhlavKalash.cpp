/*
 * Alumno: Angel Barrilao Bensrhir
 * Grupo: A3
 */

// Basado en Mancala.cpp
#include "KhlavKalash.h"
#include <string>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <utility>
#include <chrono>
#include <ctime>
#include <ratio>


using namespace std;
using namespace std::chrono;

KhlavKalash::KhlavKalash() {
	// Inicializar las variables necesarias para ejecutar la partida
	primeraEjecucion=true;
	nodos=0;
	maxnodos=0;
	contTurnos=0;
	profundidad=10;
}

KhlavKalash::~KhlavKalash() {
	// Liberar los recursos reservados (memoria, ficheros, etc.)
}

void KhlavKalash::initialize() {
	// Inicializar el bot antes de jugar una partida
}

string KhlavKalash::getName() {
	return "KhlavKalash"; // Sustituir por el nombre del bot
}
pair<int, Move> KhlavKalash::AB_Minimax(const GameState &state,int alfa,int beta,Player ply,int profundidad){

	if(profundidad==0 || state.isFinalState()){
		return make_pair(heuristica(state),M_NONE);
	}
	if(ply==yo){//MAX
		int bestValue=MIN_INT;
		Move mov;
		for(int i=1;i<7;i++){
			if(state.getSeedsAt(yo, (Position) i) > 0){
				//nodos++;
				GameState hijo = state.simulateMove((Move) i);
				int val;
				if(hijo.getCurrentPlayer() == state.getCurrentPlayer()){
					val=AB_Minimax(hijo,alfa,beta,yo,profundidad-1).first;
				}else{
					val=AB_Minimax(hijo,alfa,beta,otro,profundidad-1).first;
				}
				if(val>bestValue){
					bestValue=val;
					mov=(Move) i;
				}
				alfa=max(alfa,bestValue);
				if(beta<=alfa){
					break;
				}
			}
		}
		return make_pair(bestValue,mov);
	}else{//MIN
		int bestValue=MAX_INT;
		Move mov;
		for(int i=1;i<7;i++){
			if(state.getSeedsAt(otro, (Position) i) > 0){
			//	nodos++;
				GameState hijo = state.simulateMove((Move) i);
				int val;
				if(hijo.getCurrentPlayer() == state.getCurrentPlayer()){
					val=AB_Minimax(hijo,alfa,beta,otro,profundidad-1).first;
				}else{
					val=AB_Minimax(hijo,alfa,beta,yo,profundidad-1).first;
				}
				if (val < bestValue) {
					bestValue = val;
					mov = (Move) i;
				}
				beta=min(beta,bestValue);
				if(beta<=alfa){
					break;
				}
			}
		}
		return make_pair(bestValue,mov);
	}
}
int KhlavKalash::heuristica(const GameState &state){
    //Variables
    int plymax_granero = state.getScore(yo);
    int plymin_granero = state.getScore(otro);
    int plymax_fichas = totalSemillas(yo, state);
    int plymin_fichas = totalSemillas(otro, state);

    //h1 - heuristica de puntos Granero restantes
    int diferencia_pts_adversario = 24 - plymin_granero;
    int h1 = (plymax_granero - plymin_granero) + diferencia_pts_adversario;

    //h2 - heuristica general de tablero
    int a= plymax_granero+plymax_fichas;
    int b = plymin_granero+plymin_fichas;
    int h2=puntos_de_robo((a-b),state);

    //h3 - heuristica de diferencia de puntos generales
    int h3=(plymax_granero-plymin_granero)+(plymax_fichas-plymin_fichas);

    //h4 - heuristica de numero de movimientos disponibles
    int h4=numero_turnos(state);

    //Hacemos la media de las heuristicas
    return (h1+h2+h3+h4)/4;

}

/**********************************************************/
int KhlavKalash::heuristica_especial(const GameState &state){
	float puntos_yo=totalSemillasAlt(yo,state);
	float puntos_otro=totalSemillasAlt(otro,state);
	float diferencia_pts=(puntos_yo-puntos_otro);
	int valorTablero=int(diferencia_pts + 0.5);//el 0.5 para redondear
	int heuristica_final=((int)puntos_de_roboAlt(valorTablero,state));
	return heuristica_final;
}

float KhlavKalash::totalSemillasAlt(const Player &p,const GameState &state){
	float total=0,granero;
	for (int i= 1; i<=6; i++) {
		total+=state.getSeedsAt(p, (Position) i);
	}
	total*=0.45;
	granero=state.getScore(p)*3.45;
	return (total+granero);
}

float KhlavKalash::puntos_de_roboAlt(float valorTablero,const GameState &state){
	//Para la Maquina(YO) (MAX)
	for (int i=1;i<=6;i++){
		if (state.getSeedsAt(yo, (Position) i) == 0 && state.isValidState()){
			int pos=getPosOponente(i);
			int num_fichas=state.getSeedsAt(otro,((Position)pos));//Miramos las semillas de nuestro oponente
			valorTablero+=((num_fichas*0.5));
		}
	}
	//Para el contrincante(OTRO) (MIN)
	for (int i=1;i<=6;i++){
		if (state.getSeedsAt(otro, (Position) i) == 0 && state.isValidState()){//Si mi casilla esta vacia
			int pos=getPosOponente(i);
			int num_fichas=state.getSeedsAt(yo,((Position)pos));// Pero la de mi oponente no lo esta .... miramos las semillas de nuestro oponente
			valorTablero+=((num_fichas*0.5)*(-1));
		}
	}
	return valorTablero;
}
/***********************************************************/

int KhlavKalash::numero_turnos(Player p,const GameState &state){
	int cont=0;
	for (int i=1;i<=6;i++){
		if (state.getSeedsAt(p, (Position) i) == i){
			cont++;
		}
		if (state.getSeedsAt(p, (Position) i) > 0){
			cont++;
		}
	}
	return cont;
}
int KhlavKalash::numero_turnos(const GameState &state){
	int cont=0;
	for (int i=1;i<=6;i++){
		if (state.getSeedsAt(yo, (Position) i) == i){
			cont++;
		}
		if (state.getSeedsAt(yo, (Position) i) > 0){
			cont++;
		}
	}
	return cont;
}
int KhlavKalash::puntos_de_robo(Player p,int valorTablero,const GameState &state){
	int v=0;
	for (int i=1;i<=6;i++){
			if (state.getSeedsAt(p, (Position) i) == 0 && state.isValidState()){
				int pos=getPosOponente(i);
				int num_fichas=state.getSeedsAt(p,((Position)pos));//Miramos las semillas de nuestro oponente
				v+=num_fichas;
			}
		}
	return v;
}

int KhlavKalash::puntos_de_robo(int valorTablero,const GameState &state){
	//Para la Maquina(YO) (MAX)
	for (int i=1;i<=6;i++){
		if (state.getSeedsAt(yo, (Position) i) == 0 && state.isValidState()){
			int pos=getPosOponente(i);
			int num_fichas=state.getSeedsAt(otro,((Position)pos));//Miramos las semillas de nuestro oponente
			valorTablero+=num_fichas;
		}
	}
}

int KhlavKalash::totalSemillas(const Player &p,const GameState &state){
	float total=0,granero=0;
	for (int i= 1; i<=6; i++) {
		total+=state.getSeedsAt(p, (Position) i);
	}
	return (total+granero);
}

int KhlavKalash::getPosOponente(int pos){ //find across bin
	int pos_inv = -1;
	if(pos == 1){
		pos_inv=6;
	}else if(pos== 2){
		pos_inv=5;
	}else if(pos== 3){
		pos_inv=4;
	}else if(pos== 4){
		pos_inv=3;
	}else if(pos== 5){
		pos_inv=2;
	}else if(pos== 6){
		pos_inv=1;
	}
	return pos_inv;
}

void KhlavKalash::whoami(){
	if(J1 == this->getPlayer()){
		yo=J1;
		otro=J2;
	}else if(J2 == this->getPlayer()){
		yo=J2;
		otro=J1;
	}
}

/**********************************************************************/
Move KhlavKalash::nextMove(const vector<Move> &adversary, const GameState &state) {
	/*
	 * Numero de nodos por nivel:
	 * niv 13: p1:472.614 , p2:936.795
	 * niv 12: p1:190.922 , p2:410.772
	 * niv 11: p1:105.781 , p2:193.885
	 * niv 10: p1:65.491 ,  p2:94.610 <-- Limite de 140.000 (Requisito evaluacion)
	 * */
	Move movimiento=(Move)-1;//Si hay algun error forzamos un empate

	if(primeraEjecucion){
		primeraEjecucion=false;
		whoami();
	}

/*	if(nodos>=maxnodos){
		maxnodos=nodos;
	}
	nodos=0;*/
	//auto start = chrono::steady_clock::now();

	if(yo == J1)
		movimiento=AB_Minimax(state,MIN_INT,MAX_INT,yo,profundidad+1).second;
	else
		movimiento=AB_Minimax(state,MIN_INT,MAX_INT,yo,profundidad).second;


	//auto end = chrono::steady_clock::now();
	//duration<double> time_span = duration_cast<duration<double>>(end - start);
	//cerr<<"NUMERO DE NODOS: "<<maxnodos<<" Segundos: "<<time_span.count() <<endl;
  //cerr<<"NUMERO DE NODOS: "<<maxnodos<<endl;


	return movimiento;
}
